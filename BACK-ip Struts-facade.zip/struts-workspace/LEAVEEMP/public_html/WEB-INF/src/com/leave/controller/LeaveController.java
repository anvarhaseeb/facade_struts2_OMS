/*LeaveController.java-> The Controller class for Leave Module and it goes to the interface to FacadeManager*/

package com.leave.controller;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.json.JSONArray;

import com.kott.ejbx.LeaveModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;
import com.leave.dao.LeaveDao;
import com.leave.model.LeaveModel;

public class LeaveController {
	FacadeManager facade = new FacadeManagerBean();
	
	public String leaveApply(LeaveModelValue modelValue) {
		String str = facade.applyleave(modelValue);
		return str;
	}

	public JSONArray leaveStatus(int empid) {
		List<LeaveModelValue> leaveList = facade.leaveStatus(empid);

		List<LeaveModelValue> sortedList = leaveList.stream()
				.sorted(Comparator.comparing((LeaveModelValue leave) -> {
					switch (leave.getStatus()) {
					case "pending":
						return 0;
					case "approved":
						return 1;
					case "rejected":
						return 2;
					default:
						return 3;
					}
				}))
				.collect(Collectors.toList());

		JSONArray leavesList = new JSONArray(sortedList);
		return leavesList;
	}



	public JSONArray leavePageAdmin() {
		List<LeaveModelValue> leaveList = facade.leaveStatusAdmin();
		List<LeaveModelValue> sortedList = leaveList.stream()
				.sorted(Comparator.comparing((LeaveModelValue leave) -> {
					switch (leave.getStatus()) {
					case "pending":
						return 0;
					case "approved":
						return 1;
					case "rejected":
						return 2;
					default:
						return 3;
					}
				}))
				.collect(Collectors.toList());

		JSONArray leavesList = new JSONArray(sortedList);
		return leavesList;
	}

	public String leaveApprove(int leaveId) {
		String str = facade.approveLeave(leaveId);
		return str;
	}

	public String leaveDeny(int leaveId) {
		String str = facade.denyLeave(leaveId);
		return str;
	}

	public String leaveDelete(int leaveId) {
		String str = facade.deleteLeave(leaveId);
		return str;
	}

	

}
