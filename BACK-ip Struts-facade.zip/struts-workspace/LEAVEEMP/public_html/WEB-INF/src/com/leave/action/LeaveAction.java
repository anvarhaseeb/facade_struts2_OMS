/*LeaveAction.java-> The action class for Leave Module*/
package com.leave.action;

import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.json.JSONArray;

import com.kott.ejbx.LeaveModelValue;
import com.leave.controller.LeaveController;
import com.leave.model.LeaveModel;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.interceptor.ValidationAware;

public class LeaveAction extends ActionSupport implements ModelDriven<LeaveModel> ,SessionAware,ValidationAware{

	private static final long serialVersionUID = 1L;
	LeaveModel model = new LeaveModel();
	LeaveModelValue modelValue = new LeaveModelValue();
	private Map<String, Object> session;
	LeaveController leaveController = new LeaveController();

	public String leave() {

		session.put("empid", model.getEmpid());
		session.put("username", model.getUsername());
		int empid = (Integer) session.get("empid");
		model.setEmpid(empid);
		model.setUsername(model.getUsername());
		return "success";
	}

	/*LeaveApply  -by employee*/
	public String leaveApply() {

		if(!validLogin()) {	
			return "input";
		}
		modelValue.setEmpid(model.getEmpid());
		modelValue.setFromdate(model.getFromdate());
		modelValue.setTodate(model.getFromdate());
		modelValue.setLeavetype(model.getLeavetype());
		modelValue.setReason(model.getReason());
		modelValue.setStatus(model.getStatus());
		modelValue.setUsername(model.getUsername());

		String str = leaveController.leaveApply(modelValue);		
		model.setEmpid(modelValue.getEmpid());
		model.setUsername(modelValue.getUsername());

		return str;
	}

	/*LeaveStatus  -by employee*/
	public String leaveStatus() {
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getUsername());
		JSONArray  leaveLists = leaveController.leaveStatus(modelValue.getEmpid());
		model.setLeaveLists(leaveLists);
		model.setEmpid(modelValue.getEmpid());
		model.setUsername(modelValue.getUsername());

		session.put("empid", model.getEmpid());
		session.put("username", model.getUsername());
		return "success";
	}


	/*Leave  Reject or Approve  -by admin*/
	public String leaveAdmin() {

		if (model.getUsername() != null) {
			session.put("empid", model.getEmpid());
			session.put("username", model.getUsername());
		}
		JSONArray  leaveLists = leaveController.leavePageAdmin();
		model.setLeaveLists(leaveLists);
		return "success";
	}
	/*LeaveDatas   -by admin*/
	public String leaveDatas() {

		if (model.getUsernames() != null) {
			session.put("username", model.getUsernames());
			session.put("empid", model.getEmpid());
		}

		

		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getUsername());
		JSONArray  leaveLists = leaveController.leaveStatus(modelValue.getEmpid());
		model.setLeaveLists(leaveLists);
		model.setEmpid( (Integer) session.get("empid"));
		model.setUsername( (String) session.get("username"));

	
		return "success";
	}
	/*Leave  Approve  -by admin*/
	public String toApprove() {
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getUsername());
		modelValue.setLeaveId(model.getLeaveId());
		String  str = leaveController.leaveApprove(modelValue.getLeaveId());
		model.setActionMessage("Approved"); 
		model.setEmpid(modelValue.getEmpid());
		model.setUsername(modelValue.getUsername());
		return str;
	}
	/*Leave  Approve  -by admin*/
	public String toDeny() {
		modelValue.setLeaveId(model.getLeaveId());
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getEmpname());
		String  str = leaveController.leaveDeny(modelValue.getLeaveId());
		model.setActionMessage("Rejected"); 
		model.setEmpid(modelValue.getEmpid());
		model.setUsername(modelValue.getUsername());
		return str;
	}
	/*Leave  Approve  -by employee*/
	public String toDelete() {
		modelValue.setLeaveId(model.getLeaveId());
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getEmpname());
		String  str = leaveController.leaveDelete(modelValue.getLeaveId());

		model.setEmpid((Integer) session.get("empid"));
		model.setUsername((String) session.get("username"));

		System.out.println(model.getEmpid()+"---id delete sesion");
		System.out.println(model.getUsername()+"---user delete");
		model.setActionMessage("Deleted"); 
		return str;
	}

	/*Validation Checking of the Employee Dashboard's leave Applying*/
	public boolean validLogin() {

		if (model.getFromdate().equals(model.getTodate())) {
			addFieldError("model.todate", "The from and To dates can't be Same");
			return false;
		}
		if (model.getLeavetype() == null || model.getLeavetype().isEmpty()) {
			addFieldError("model.leavetype", "Please select a leave type");
			return false;
		}

		String reason = model.getReason();
		if (reason == null || reason.isEmpty()) {
			addFieldError("model.reason", "Reason can't be blank");
			return false;
		}

		else {
			return true;
		}
	}

	@Override
	public void setSession(Map<String, Object> session) {

		this.session = session;
	}

	@Override
	public LeaveModel getModel() {

		return model;
	}
	@Override
	public String execute() throws Exception {
		return null;
	}

}

