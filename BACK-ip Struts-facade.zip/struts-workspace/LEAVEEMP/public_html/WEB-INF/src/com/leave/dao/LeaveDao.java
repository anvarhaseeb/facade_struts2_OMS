package com.leave.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.leave.model.LeaveModel;

public class LeaveDao {
	/*Emp - Leave Apply*/
    public String applyleave(LeaveModel model) {
        Connection con = DBConnect.getConnection();

        String sql = "INSERT INTO Leave (empid, fromdate, todate, leavetype, reason, status) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, model.getEmpid());
            ps.setString(2, model.getFromdate());
            ps.setString(3, model.getTodate());
            ps.setString(4, model.getLeavetype());
            ps.setString(5, model.getReason());
            ps.setString(6, "pending");
            int rowsInserted = ps.executeUpdate();

            if (rowsInserted > 0) {
                return "success";
            } else {
                return "error";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "error";
        }
    }


    /*Employee - Leave Status*/
	public List<LeaveModel> leaveStatus(int empid) {
        Connection con = DBConnect.getConnection();

        String sql = "SELECT * FROM Leave where empid=?";
        List<LeaveModel>leaveList = new ArrayList<>();

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, empid);

			ResultSet resultSet = ps.executeQuery();

			   while (resultSet.next()) {
		            Integer LeaveId = resultSet.getInt("LeaveId");
		            String fromdate = resultSet.getString("fromdate");
		            String todate = resultSet.getString("todate");
		            String leavetype = resultSet.getString("leavetype");
		            String reason = resultSet.getString("reason");
		            String status = resultSet.getString("status");

		            LeaveModel leave = new LeaveModel();
		            leave.setLeaveId(LeaveId);
		            leave.setEmpid(empid);
		            leave.setFromdate(fromdate);
		            leave.setTodate(todate);
		            leave.setLeavetype(leavetype);
		            leave.setReason(reason);
		            leave.setStatus(status);

		            leaveList.add(leave);
		        }

		} catch (SQLException e) {
			e.printStackTrace(); 
		} 
		return leaveList;
	}


	/*Admin - Leave Status*/
	public List<LeaveModel> leaveStatusAdmin() {
	    Connection con = DBConnect.getConnection();
	    String sql = "SELECT Leave.LeaveId, Leave.empid, Employees.empname, Leave.fromdate, Leave.todate, Leave.leavetype, Leave.reason, Leave.status " +
	                 "FROM Leave " +
	                 "LEFT JOIN Employees ON Leave.empid = Employees.empid";
	    List<LeaveModel> leaveList = new ArrayList<>();

	    try {
	        PreparedStatement ps = con.prepareStatement(sql);
	        ResultSet resultSet = ps.executeQuery();

	        while (resultSet.next()) {
	            Integer leaveId = resultSet.getInt("LeaveId");
	            Integer empid = resultSet.getInt("empid");
	            String empname = resultSet.getString("empname"); 
	            String fromdate = resultSet.getString("fromdate");
	            String todate = resultSet.getString("todate");
	            String leavetype = resultSet.getString("leavetype");
	            String reason = resultSet.getString("reason");
	            String status = resultSet.getString("status");

	            LeaveModel leave = new LeaveModel();
	            leave.setLeaveId(leaveId);
	            leave.setEmpid(empid);
	            leave.setEmpname(empname); 
	            leave.setFromdate(fromdate);
	            leave.setTodate(todate);
	            leave.setLeavetype(leavetype);
	            leave.setReason(reason);
	            leave.setStatus(status);

	            leaveList.add(leave);
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	    } 
	    return leaveList;
	}


	public String approveLeave(int leaveId) {
	    Connection con = DBConnect.getConnection();

	    String sql = "UPDATE Leave SET status = 'approved' WHERE LeaveId = ?";

	    try {
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.setInt(1, leaveId);

	        int rowsUpdated = ps.executeUpdate();

	        if (rowsUpdated > 0) {
	            return "success"; 
	        } else {
	            return "error"; 
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();

	        return "error"; 
	    }
	}


	public String approveDeny(int leaveId) {
	    Connection con = DBConnect.getConnection();

	    String sql = "UPDATE Leave SET status = 'rejected' WHERE LeaveId = ?";

	    try {
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.setInt(1, leaveId);

	        int rowsUpdated = ps.executeUpdate();

	        if (rowsUpdated > 0) {
	            return "success"; 
	        } else {
	            return "error"; 
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	        return "error"; 
	    }
	}


	public String approveDelete(int leaveId) {
	    Connection con = DBConnect.getConnection();
	    String sql = "DELETE FROM Leave WHERE LeaveId = ?";
	    try {
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.setInt(1, leaveId);

	        int rowsUpdated = ps.executeUpdate();

	        if (rowsUpdated > 0) {
	            return "success"; 
	        } else {
	            return "error"; 
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	        return "error"; 
	    }
	}

	}

