package com.announcement.action;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import org.apache.struts2.interceptor.SessionAware;
import com.announcement.conroller.AnnounceController;
import com.announcement.model.AnnounceModel;
import com.kott.ejbx.AnnounceModelValue;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.profile.model.ProfileModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AnnounceAction extends ActionSupport implements ModelDriven<AnnounceModel > ,SessionAware{

	private static final long serialVersionUID = 1L;
	AnnounceModel model = new AnnounceModel();
	AnnounceController ann = new AnnounceController();
	AnnounceModelValue modelValue = new AnnounceModelValue();
	private Map<String, Object> session;
	private static final Logger logger = LoggerFactory.getLogger(AnnounceAction.class);

	public String announce() {
		logger.info("in announce");
		if (model.getUsername() != null) 
		{
			session.put("username", model.getUsername());
			session.put("type", model.getType());
		}
		model.setType(model.getType());

		return "success";
	}

	public String send() {
		if (model.getUsername() != null) {

			session.put("username", model.getUsername());
			session.put("type", model.getType());
		}

		modelValue.setUsername(model.getUsername());
		modelValue.setAnnounced_date(model.getAnnounced_date());
		modelValue.setMessage(model.getMessage());
		modelValue.setType(model.getType());

		String types= ann.sendAnnounceCtrl(modelValue);
		model.setType(modelValue.getType());
		model.setType(model.getType());

		return types;
	}

	public String view() {
		modelValue.setUsername(model.getUsername());
		modelValue.setAnnounced_date(model.getAnnounced_date());
		modelValue.setMessage(model.getMessage());
		modelValue.setType(model.getType());
		List<AnnounceModelValue> AnnounceValueList = ann.viewAnnounceCtrl(modelValue);
		List<AnnounceModel> AnnounceList = new ArrayList<>();

		AnnounceValueList.forEach(x -> {
			AnnounceModel ann = new AnnounceModel();
			ann.setAid(x.getAid());
			ann.setUsername(x.getUsername()); 
			ann.setAnnounced_date(x.getAnnounced_date());
			ann.setMessage(x.getMessage()); 
			ann.setType(x.getType()); 
			AnnounceList.add(ann);
		}	);

		model.setAnnounceList(AnnounceList);
		model.setUsername(modelValue.getUsername());
		System.out.println("in announce +"+model.getUsername());
		if (model.getUsername() != null) 
		{
			session.put("username", model.getUsername());
		
		}
		return "success"; 
	}
	public String delete() {
		modelValue.setAid(model.getAid());
		String types = ann.deleteAnnounceCtrl(modelValue.getAid());
		model.setType(modelValue.getType());
		model.setType(model.getType());
		return types; 
	}
	@Override
	public AnnounceModel getModel() {

		return model;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		this.session =session;
	}

}
