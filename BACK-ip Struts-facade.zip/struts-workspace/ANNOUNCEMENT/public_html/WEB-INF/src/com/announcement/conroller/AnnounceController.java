package com.announcement.conroller;

import java.util.Collections;
import java.util.List;


import com.kott.ejbx.AnnounceModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;


public class AnnounceController {

	FacadeManager facade = new FacadeManagerBean() ;
	
	public String sendAnnounceCtrl(AnnounceModelValue modelValue) {
		String type = facade.sendAnnounce(modelValue);
		return type;
	}
	
	 public List<AnnounceModelValue> viewAnnounceCtrl(AnnounceModelValue modelValue) { 
		 
	  List<AnnounceModelValue> AnnounceList =facade.viewAnnounce(modelValue);
	  Collections.reverse(AnnounceList);
	 return AnnounceList; 
	 }

	public String deleteAnnounceCtrl(int aid) {
		String type = facade.deleteAnnounce(aid);
		return type;
	}
	 
}
