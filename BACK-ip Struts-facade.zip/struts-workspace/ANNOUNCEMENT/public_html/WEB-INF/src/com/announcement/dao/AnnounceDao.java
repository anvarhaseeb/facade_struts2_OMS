//package com.announcement.dao;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//import com.admin.model.EmployeeModel;
//import com.announcement.model.AnnounceModel;
//import com.profile.model.ProfileModel;
//
//public class AnnounceDao {
//	static Connection con = DBConnect.getConnection();
//
//	public String sendAnnounce(AnnounceModel model) {
//		String sql = "INSERT INTO announcement (username, announced_date, message,type) VALUES (?, ?, ?,?)";
//
//		try {
//			PreparedStatement ps = con.prepareStatement(sql);
//			ps.setString(1, model.getUsername());
//			ps.setString(2, model.getAnnounced_date());
//			ps.setString(3, model.getMessage());
//			ps.setString(4, model.getType());
//			int rowsInserted = ps.executeUpdate();
//
//			if (rowsInserted > 0) {
//			
//				return "success";
//			} else {
//			
//				return "error";
//			}
//		} catch (SQLException e) {
//
//			e.printStackTrace();
//			return "error";
//		}
//	}
//
//	public List<AnnounceModel> viewAnnounce(AnnounceModel model) {
//	    List<AnnounceModel> AnnounceList = new ArrayList<AnnounceModel>();
//
//	    String sql = "SELECT * FROM announcement";
//
//	    try {
//	        PreparedStatement ps = con.prepareStatement(sql);
//	        ResultSet resultSet = ps.executeQuery();
//
//	        while (resultSet.next()) {
//	            AnnounceModel am = new AnnounceModel();
//	            am.setAid(resultSet.getInt("aid"));
//	            am.setUsername(resultSet.getString("username")); 
//	            am.setAnnounced_date(resultSet.getString("announced_date"));
//	            am.setMessage(resultSet.getString("message")); 
//	            am.setType(resultSet.getString("type")); 
//	            
//	            AnnounceList.add(am);
//	        }
//
//	    } catch (SQLException e) {
//	        e.printStackTrace();
//
//	    }
//
//	    return AnnounceList;
//	}
//
//	public String deleteAnnounce(int aid) {
//	
//			String sql1 = "Delete from announcement where aid = ?";
//			
//			try {
//				PreparedStatement ps1 = con.prepareStatement(sql1);
//				ps1.setInt(1,aid);
//
//				int rowEmpDeleted = ps1.executeUpdate();
//
//				
//				if(rowEmpDeleted > 0){
//				     return "success";
//		        } else {
//		            return "error";
//		        }
//		    } catch (SQLException e) {
//		        e.printStackTrace();
//
//		    }
//			return "success";
//		}
//
//}
