package com.announcement.model;

import java.util.List;

public class AnnounceModel {
	private int aid;
    private String username;
    private String announced_date;
    private String message;
    
    private int empid;
    private String type;
   private  List<AnnounceModel> AnnounceList;


    public String getUsername() {
        return username;
    }

    public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public void setUsername(String username) {
        this.username = username;
    }


    public String getAnnounced_date() {
        return announced_date;
    }

    public void setAnnounced_date(String announced_date) {
        this.announced_date = announced_date;
    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

	public List<AnnounceModel> getAnnounceList() {
		return AnnounceList;
	}

	public void setAnnounceList(List<AnnounceModel> announceList) {
		AnnounceList = announceList;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	@Override
	public String toString() {
		return "AnnounceModel [username=" + username + ", announced_date=" + announced_date + ", message=" + message
				+  "]";
	}
    
}
