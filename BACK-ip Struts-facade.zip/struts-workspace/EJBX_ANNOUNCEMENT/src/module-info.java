/**
 * 
 */
/**
 * 
 */
module EJBX_ANNOUNCEMENT {
	requires java.sql;
	requires jdk.jpackage;
}