package com.kott.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.kott.database.DBConnect;
import com.kott.ejbx.AnnounceModelValue;

public class FacadeManagerBean implements FacadeManager {
	 Connection con = DBConnect.getConnection();

	public String sendAnnounce(AnnounceModelValue modelValue) {
		String sql = "INSERT INTO announcement (username, announced_date, message,type) VALUES (?, ?, ?,?)";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, modelValue.getUsername());
			ps.setString(2, modelValue.getAnnounced_date());
			ps.setString(3, modelValue.getMessage());
			ps.setString(4, modelValue.getType());
			int rowsInserted = ps.executeUpdate();

			if (rowsInserted > 0) {
			
				return "success";
			} else {
			
				return "error";
			}
		} catch (SQLException e) {

			e.printStackTrace();
			return "error";
		}
	}

	public List<AnnounceModelValue> viewAnnounce(AnnounceModelValue modelValue) {
	    List<AnnounceModelValue> AnnounceList = new ArrayList<AnnounceModelValue>();

	    String sql = "SELECT * FROM announcement";

	    try {
	        PreparedStatement ps = con.prepareStatement(sql);
	        ResultSet resultSet = ps.executeQuery();

	        while (resultSet.next()) {
	        	AnnounceModelValue am = new AnnounceModelValue();
	            am.setAid(resultSet.getInt("aid"));
	            am.setUsername(resultSet.getString("username")); 
	            am.setAnnounced_date(resultSet.getString("announced_date"));
	            am.setMessage(resultSet.getString("message")); 
	            am.setType(resultSet.getString("type")); 
	            
	            AnnounceList.add(am);
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();

	    }

	    return AnnounceList;
	}

	public String deleteAnnounce(int aid) {
	
			String sql1 = "Delete from announcement where aid = ?";
			
			try {
				PreparedStatement ps1 = con.prepareStatement(sql1);
				ps1.setInt(1,aid);

				int rowEmpDeleted = ps1.executeUpdate();

				
				if(rowEmpDeleted > 0){
				     return "success";
		        } else {
		            return "error";
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();

		    }
			return "success";
		}

}
