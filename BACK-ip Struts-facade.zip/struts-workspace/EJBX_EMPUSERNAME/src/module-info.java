/**
 * 
 */
/**
 * 
 */
module EJBX_EMPUSERNAME {
	requires java.sql;
}