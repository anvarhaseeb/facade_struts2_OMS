package com.kott.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.kott.database.DBConnect;
import com.kott.ejbx.EmpLogCreateModelValue;



public class FacadeManagerBean  implements FacadeManager{
	Connection  con = DBConnect.getConnection();

	/*View-Search Log list*/
	public List<EmpLogCreateModelValue> viewLog() {
		List<EmpLogCreateModelValue> LogList= new ArrayList<>();
		String sql = "SELECT  *from Login";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet resultSet = ps.executeQuery();

			while (resultSet.next()) {
				int empid= resultSet.getInt("emp_id");
				String username= resultSet.getString("username");
				String password= resultSet.getString("password");
				String type= resultSet.getString("type");

				EmpLogCreateModelValue log =new EmpLogCreateModelValue();
				log.setEmpid(empid);
				log.setUsername(username);
				log.setPassword(password);
				log.setType(type);
				LogList.add(log);

			}
			return LogList;
		} catch (SQLException e) {
			e.printStackTrace(); 
		}
		return LogList; 
	}

	/* delete method */
	public String delete(int empid) {
		String sql="delete  from Login where emp_id =?";
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1,empid);
			int rowDeleted = ps.executeUpdate();

			if(rowDeleted > 0) {
				return "success";
			}
			else {
				return "error";
			}

		}catch (SQLException e) {
			e.printStackTrace(); 
			return "error";
		}

	}

	/*Employee Login Object returning to pass the value to edit page*/
	public EmpLogCreateModelValue emplogListempid(int empid2) {
		String sql = "SELECT  *from Login where emp_id =?";
		EmpLogCreateModelValue log =new EmpLogCreateModelValue();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1,empid2);
			ResultSet resultSet = ps.executeQuery();

			while (resultSet.next()) {
				int empid= resultSet.getInt("emp_id");
				String username= resultSet.getString("username");
				String password= resultSet.getString("password");
				String type= resultSet.getString("type");


				log.setEmpid(empid);
				log.setUsername(username);
				log.setPassword(password);
				log.setType(type);


			}
			return log;
		} catch (SQLException e) {
			e.printStackTrace(); 
		}
		return log; 
	}

	public String editLog(EmpLogCreateModelValue model) {
		String sql = "UPDATE LOGIN SET  username = ?,password =? ,type=? WHERE emp_id = ?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, model.getUsername());
			ps.setString(2, model.getPassword());
			ps.setString(3, model.getType());
			ps.setInt(4, model.getEmpid());

			int rowsUpdated = ps.executeUpdate();

			if (rowsUpdated > 0) {
				return "success";
			} else {
				return "error";
			}
		} catch (SQLException e) {
			e.printStackTrace(); 
			return "error";
		}

	}

	public String addLog(EmpLogCreateModelValue model) {

		String sql = "INSERT INTO Login (emp_id,username,password,type)  VALUES (?, ?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);

			ps.setInt(1, model.getEmpid());
			ps.setString(2, model.getUsername());
			ps.setString(3, model.getPassword());
			ps.setString(4, model.getType());
			int rowsInserted = ps.executeUpdate();

			if (rowsInserted > 0) {
				return "success";
			} else {
			}

		} catch (SQLException e) {
			e.printStackTrace(); 
			return "error";
		}
		return "success";
	}

	public boolean checkuname(String username,int empid)  {
		 String sql = "SELECT COUNT(*) FROM login WHERE username = ? or emp_id =?";
	        try {
	        PreparedStatement preparedStatement = con.prepareStatement(sql);
	        preparedStatement.setString(1, username);
	        preparedStatement.setInt(2, empid);
	        ResultSet resultSet = preparedStatement.executeQuery();
	        resultSet.next();
	        int count = resultSet.getInt(1);
	        return count > 0;
	        }catch (SQLException e) {
				e.printStackTrace(); 
				
			}
			return false;    
	}
}


