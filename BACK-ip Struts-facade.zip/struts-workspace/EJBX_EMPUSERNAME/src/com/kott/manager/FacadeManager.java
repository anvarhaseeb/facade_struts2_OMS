package com.kott.manager;

import java.util.List;

import com.kott.ejbx.EmpLogCreateModelValue;

public interface FacadeManager {

	public List<EmpLogCreateModelValue> viewLog() ;
	public EmpLogCreateModelValue emplogListempid(int empid2) ;
	public String editLog(EmpLogCreateModelValue model) ;
	public String addLog(EmpLogCreateModelValue model) ;
	public boolean checkuname(String username,int empid)  ;
	public String delete(int empid);
}
