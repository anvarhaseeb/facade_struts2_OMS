
package com.admin.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.json.JSONArray;

import com.admin.controller.AdminController;
import com.admin.model.DepartmentModel;
import com.admin.model.EmployeeModel;
import com.kott.ejbx.DepartmentModelValue;
import com.kott.ejbx.EmployeeModelValue;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class AdminAction extends ActionSupport implements ModelDriven<EmployeeModel > , SessionAware {

	private static final long serialVersionUID = 1L;
	EmployeeModel   model = new EmployeeModel ();
	EmployeeModelValue modelValue = new EmployeeModelValue();
	String id;
	List<DepartmentModelValue>  DeptValueList = new ArrayList<>(); ;
	List<DepartmentModel>  DeptList = new ArrayList<>();;
	AdminController adminController = new AdminController();
	String actionName;
	JSONArray  EmpListJson;

	private Map<String, Object> session;

	public String home() {

		DeptValueList = adminController.viewDeptCtrlforSearch(); 
		
		DeptValueList.forEach(x ->{
			DepartmentModel dept =new DepartmentModel();
			dept.setDeptID(x.getDeptID());
			dept.setDeptname(x.getDeptname());
			DeptList.add(dept);
		});
		
		model.setDeptList(DeptList);
		if (model.getUsername() != null) {

			session.put("username", model.getUsername());
			session.put("type", model.getType());
		}
		return "success";
	}
	public String addPage() { 
		model.setActionName("ADD");
		DeptValueList = adminController.viewDeptCtrlforSearch(); 
		DeptValueList.forEach(x ->{
			DepartmentModel dept =new DepartmentModel();
			dept.setDeptID(x.getDeptID());
			dept.setDeptname(x.getDeptname());
			DeptList.add(dept);
		});
		model.setDeptList(DeptList);
		return "success";
	}
	public String editPage() {
		model.setActionName("EDIT");
		modelValue.setEmpid(model.getEmpid());
		modelValue =adminController.emplistCtrl(modelValue.getEmpid());

		model.setEmpid(modelValue.getEmpid());
		model.setEmpname(modelValue.getEmpname());
		model.setDob(modelValue.getDob());
		model.setQualification(modelValue.getQualification());
		model.setPhn(modelValue.getPhn());
		model.setEmail(modelValue.getEmail());
		model.setExp(modelValue.getExp());
		model.setCmpname(modelValue.getCmpname());
		model.setAddress(modelValue.getAddress());
		model.setDoj(modelValue.getDoj());
		model.setDept(modelValue.getDept());

		
		DeptValueList = adminController.viewDeptCtrlforSearch(); 
		DeptValueList.forEach(x ->{
			DepartmentModel dept =new DepartmentModel();
			dept.setDeptID(x.getDeptID());
			dept.setDeptname(x.getDeptname());
			DeptList.add(dept);
		});

		model.setDeptList(DeptList);

		return "success";
	}

	public String actionEmp() {
		DeptValueList = adminController.viewDeptCtrlforSearch(); 
		DeptValueList.forEach(x ->{
			DepartmentModel dept =new DepartmentModel();
			dept.setDeptID(x.getDeptID());
			dept.setDeptname(x.getDeptname());
			DeptList.add(dept);
		});
		model.setDeptList(DeptList);

		if(model.getActionName().equals("ADD")) {
			
			modelValue.setEmpid(model.getEmpid());
			modelValue.setEmpname(model.getEmpname());
			modelValue.setDob(model.getDob());
			modelValue.setQualification(model.getQualification());
			modelValue.setPhn(model.getPhn());
			modelValue.setEmail(model.getEmail());
			modelValue.setExp(model.getExp());
			modelValue.setCmpname(model.getCmpname());
			modelValue.setAddress(model.getAddress());
			modelValue.setDoj(model.getDoj());
			modelValue.setDept(model.getDept());

			String type = adminController.addEmpCtrl(modelValue);
			addActionMessage("The data inserted successfully"); 
			return type;
		}
		else if(model.getActionName().equals("EDIT")) {
			modelValue.setEmpid(model.getEmpid());
			modelValue.setEmpname(model.getEmpname());
			modelValue.setDob(model.getDob());
			modelValue.setQualification(model.getQualification());
			modelValue.setPhn(model.getPhn());
			modelValue.setEmail(model.getEmail());
			modelValue.setExp(model.getExp());
			modelValue.setCmpname(model.getCmpname());
			modelValue.setAddress(model.getAddress());
			modelValue.setDoj(model.getDoj());
			modelValue.setDept(model.getDept());

			String type = adminController.editEmpCtrl(modelValue);
			addActionMessage("The data edited successfully"); 
			return type;
		}
		else {
			return "error";
		}

	}

	/* Search */
	public String search()throws Exception  {
		
		modelValue.setEmpid(model.getEmpid());
		modelValue.setEmpname(model.getEmpname());
		modelValue.setDob(model.getDob());
		modelValue.setQualification(model.getQualification());
		modelValue.setPhn(model.getPhn());
		modelValue.setEmail(model.getEmail());
		modelValue.setExp(model.getExp());
		modelValue.setCmpname(model.getCmpname());
		modelValue.setAddress(model.getAddress());
		modelValue.setDoj(model.getDoj());
		modelValue.setDept(model.getDept());
		
		EmpListJson = adminController.searchCtrl(modelValue); 
		model.setEmpListJson(EmpListJson);
		model.setUsername((String)session.get("username"));
		return "success";
	}

	/* delete */
	public String delete()throws Exception  {
		
		modelValue =adminController.emplistCtrl(model.getEmpid());
		
		model.setEmpid(modelValue.getEmpid());
		model.setEmpname(modelValue.getEmpname());
		model.setDob(modelValue.getDob());
		model.setQualification(modelValue.getQualification());
		model.setPhn(modelValue.getPhn());
		model.setEmail(modelValue.getEmail());
		model.setExp(modelValue.getExp());
		model.setCmpname(modelValue.getCmpname());
		model.setAddress(modelValue.getAddress());
		model.setDoj(modelValue.getDoj());
		model.setDept(modelValue.getDept());
		
		String type = adminController.deleteCtrl(modelValue); 
		if(type.equals("cannotDelete")) {

			addActionMessage("Can't delete Admin data"); 
		}
		model.setId(modelValue.getEmpname());
		return type;
	}



	@Override
	public EmployeeModel getModel() {
		return model;
	}

	@Override
	public String execute() throws Exception {
		return null;
	}


	@Override
	public void setSession(Map<String, Object> session) {
		this.session= session;

	}




}
