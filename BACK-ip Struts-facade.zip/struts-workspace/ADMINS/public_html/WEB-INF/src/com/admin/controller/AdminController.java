package com.admin.controller;

import java.util.List;

import org.json.JSONArray;

import com.kott.ejbx.DepartmentModelValue;
import com.kott.ejbx.EmployeeModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;

public class AdminController {
	FacadeManager facade = new FacadeManagerBean()	 ;
	
	public  List<DepartmentModelValue> viewDeptCtrlforSearch() {
		List<DepartmentModelValue> DeptList= facade.viewDept();
		return DeptList;
	}

	public  String addEmpCtrl(EmployeeModelValue modelValue) {

		String type = facade.addEmp(modelValue);

		return type;

	}
	public  String editEmpCtrl(EmployeeModelValue modelValue) {
		String type = facade.editEmp(modelValue);

		return type;
	}
	public  JSONArray searchCtrl(EmployeeModelValue modelValue) {
		List<EmployeeModelValue>EmpList= facade.searchEmp(modelValue);

		JSONArray jsonArray = new JSONArray(EmpList);

		return jsonArray;
	}

	public  String deleteCtrl(EmployeeModelValue modelValue) {

		String type = facade.deleteEmp(modelValue);
		return type;
	}

	public  EmployeeModelValue  emplistCtrl(int empid) {
		return facade.showEmp(empid) ;
	}


}
