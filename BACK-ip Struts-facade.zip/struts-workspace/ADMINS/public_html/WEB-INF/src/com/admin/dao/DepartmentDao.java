/*DepartmentDa0.java=> java file to retrieve the depaertment list to displat the in select-tag of AdminHome
*/
package com.admin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.admin.model.DepartmentModel;


public class DepartmentDao {

	Connection  con = DBConnect.getConnection();

	public List<DepartmentModel> viewDept() {
		List<DepartmentModel> DeptList= new ArrayList<>();
		String sql = "SELECT  *from Department";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet resultSet = ps.executeQuery();

			while (resultSet.next()) {
				String dptid= resultSet.getString("dept_id");
				String dptname= resultSet.getString("dept_name");

				DepartmentModel d =new DepartmentModel();
				d.setDeptID(dptid);
				d.setDeptname(dptname);

				DeptList.add(d);
			}
			con.close();
		} catch (SQLException e) {
			e.printStackTrace(); 
			System.out.println("exception in view AdminDept--");
		} 

		return DeptList;
	}

}
