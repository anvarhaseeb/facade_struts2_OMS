/*DBConnect.java => To enable the connection with DataBase MsSQL*/

package com.employeeusername.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
	public static  Connection getConnection()
	{
		String jdbcUrl = "jdbc:sqlserver://ANVAR-PC:1433;databaseName=OMS;trustServerCertificate=true";
		String username = "sa";
		String password = "sa123";
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(jdbcUrl, username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
}

