/*The EMPLOYEEUSERNAME module :  EmpLogController =>Act as bridge between action class and dao*/
package com.employeeusername.controller;

import java.util.List;

import org.json.JSONArray;


import com.kott.ejbx.EmpLogCreateModelValue;
import com.kott.manager.FacadeManagerBean;
import com.kott.manager.FacadeManager;


public class EmpLogCreateController{
	EmpLogCreateModelValue modelValue = new EmpLogCreateModelValue();
	FacadeManager facade =new FacadeManagerBean();
	
	/*View Login credentials,like username password and type*/
	public  JSONArray viewLogtCtrl() {
	
		List<EmpLogCreateModelValue> LogList= facade.viewLog();
		JSONArray jsonArray = new JSONArray(LogList);
		return jsonArray;
	}
	/*Delete Login method*/
	public  String deleteLogCtrl(int empid) {
		String type = facade.delete(empid);
		return type;
	}

	/*add login credentials and check the duplicate of username and empid or not*/
	public  String addLogCtrl(EmpLogCreateModelValue modelValue) {
	
		boolean condition = facade.checkuname(modelValue.getUsername(),modelValue.getEmpid());
		if(condition) {
			return "duplicate";
		}
		else {
			String type = facade.addLog(modelValue);
			return type;
		}
	}
	/*Edit Login method*/
	public  String editLogCtrl(EmpLogCreateModelValue modelValue) {

		String type = facade.editLog(modelValue);
		return type;
	}
	/*to retrieve object of  Login to display values in text-field in edit Page*/
	public  EmpLogCreateModelValue emploglistCtrl(int empid) {
	
		return facade.emplogListempid(empid);
	}

}
