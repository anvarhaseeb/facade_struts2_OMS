$(document).ready(function() {
  $('#deptForm').on('submit', function() {
    var validationResult = $("#validationResult");
    var deptname = $("#deptname").val().trim();
    var deptID = $("#deptID").val();
  
    if (deptname === "") {
      validationResult.text("Enter the Department name");
      return false;
    }

    var firstLetter = deptname.charAt(0);
    if (firstLetter !== firstLetter.toUpperCase()) {
      validationResult.text("First letter of the name should be a capital letter");
      return false;
    }

if (deptID.length > 3) {
      console.log("deptID: " + deptID); 
      validationResult.text("Department ID shouldn't be greater than 3 characters");
      return false;
    }
  });
});
