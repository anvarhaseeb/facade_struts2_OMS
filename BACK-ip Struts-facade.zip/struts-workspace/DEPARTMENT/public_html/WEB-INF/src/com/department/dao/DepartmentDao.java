//package com.department.dao;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//import com.department.model.DepartmentModel;
//
//
//public class DepartmentDao {
//	Connection  con = DBConnect.getConnection();
//
//	public String addDept(DepartmentModel model) {
//		String sql = "INSERT INTO Department (dept_id, dept_name) VALUES (?, ?)";
//		try {
//			PreparedStatement ps = con.prepareStatement(sql);
//
//			ps.setString(1, model.getDeptID());
//			ps.setString(2, model.getDeptname());
//			int rowsInserted = ps.executeUpdate();
//			if (rowsInserted > 0) {
//				return "success";
//			} else {
//
//			}
//
//		} catch (SQLException e) {
//			e.printStackTrace(); 
//			return "error";
//		}
//		return "success";
//	}
//
//
//	public List<DepartmentModel> viewDept() {
//		List<DepartmentModel> DeptList= new ArrayList<>();
//		String sql = "SELECT  *from Department";
//
//		try {
//			PreparedStatement ps = con.prepareStatement(sql);
//			ResultSet resultSet = ps.executeQuery();
//
//			while (resultSet.next()) {
//				String dptid= resultSet.getString("dept_id");
//				String dptname= resultSet.getString("dept_name");
//
//				DepartmentModel d =new DepartmentModel();
//				d.setDeptID(dptid);
//				d.setDeptname(dptname);
//
//				DeptList.add(d);
//			}
//
//		} catch (SQLException e) {
//			e.printStackTrace(); 
//
//		} 
//
//		return DeptList;
//	}
//
//
//	public String deleteDept(DepartmentModel model) {
//		String sql = "DELETE FROM Department WHERE  dept_id = ?";
//
//		try {
//			PreparedStatement ps = con.prepareStatement(sql);
//			ps.setString(1, model.getDeptID());
//
//			int rowsDeleted = ps.executeUpdate();
//			if (rowsDeleted > 0) {
//				return "success";
//			} else {
//				return "error";
//			}
//
//		} catch (SQLException e) {
//			e.printStackTrace(); 
//			return "error";
//		}
//	}
//
//	public List<DepartmentModel> editPageList(DepartmentModel model) {
//
//		List<DepartmentModel> DeptList= new ArrayList<>();
//		String sql = "SELECT  *from Department where dept_id = ? ";
//
//		try {
//			PreparedStatement ps = con.prepareStatement(sql);
//			ps.setString(1, model.getDeptID());
//			ResultSet resultSet = ps.executeQuery();
//
//			while (resultSet.next()) {
//				String dptid= resultSet.getString("dept_id");
//				String dptname= resultSet.getString("dept_name");
//
//				DepartmentModel d =new DepartmentModel();
//				d.setDeptID(dptid);
//				d.setDeptname(dptname);
//
//				DeptList.add(d);
//			}
//			con.close();
//		} catch (SQLException e) {
//			e.printStackTrace(); 
//
//		} 
//		return DeptList;
//	}
//
//
//	public String editDept(DepartmentModel model) {
//		String sql = "UPDATE Department SET  dept_name = ? WHERE dept_id = ?";
//		try {
//			PreparedStatement ps = con.prepareStatement(sql);
//			ps.setString(1, model.getDeptname());
//			ps.setString(2, model.getDeptID());
//
//			int rowsUpdated = ps.executeUpdate();
//			if (rowsUpdated > 0) {
//
//				return "success";
//			} else {
//
//				return "error";
//			}
//		} catch (SQLException e) {
//			e.printStackTrace(); 
//			return "error";
//		}
//	}
//
//
//	public DepartmentModel deoptObj(String deptID) {
//		String sql = "SELECT  *from Department where dept_id=?";
//		try {
//			PreparedStatement ps = con.prepareStatement(sql);
//			ps.setString(1, deptID);
//
//			ResultSet resultSet = ps.executeQuery();
//			while (resultSet.next()) {
//				String dptid= resultSet.getString("dept_id");
//				String dptname= resultSet.getString("dept_name");
//				DepartmentModel dept =new DepartmentModel();
//				dept.setDeptID(dptid);
//				dept.setDeptname(dptname);
//
//				return dept;
//			}
//
//		} catch (SQLException e) {
//			e.printStackTrace(); 
//		} 
//		return null;
//	}
//}