/*DepartmentController.java => The java file mainly the bridge between action class and Dao class*/

package com.department.controller;

import java.util.List;

import org.json.JSONArray;

import com.kott.ejbx.DepartmentModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;

public class DepartmentController {
	
	FacadeManager facadeManager = new FacadeManagerBean();
	
	public String addDeptCtrl(DepartmentModelValue modelValue) {
		
		String type = facadeManager.addDept(modelValue);

		return type;
	}

	public   JSONArray viewDeptCtrl() {
		List<DepartmentModelValue> DeptList= facadeManager.viewDept();
		JSONArray jsonArray = new JSONArray(DeptList);
		return jsonArray;
	}

	public  String deleteDeptCtrl(DepartmentModelValue modelValue) {

		String type = facadeManager.deleteDept(modelValue);
		return type;
	}

	public  List<DepartmentModelValue> editPageCtrl(DepartmentModelValue modelValue) {		
		List<DepartmentModelValue> DeptList= facadeManager.editPageList(modelValue);
		return DeptList;

	}

	public  String editDeptCtrl(DepartmentModelValue model) {
		
		String type = facadeManager.editDept(model);
		return type;
	}



	public DepartmentModelValue deptobjCtrl(String deptID) {
		return facadeManager.deoptObj(deptID) ;
	}


}
