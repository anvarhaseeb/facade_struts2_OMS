/*DepartmenrModel.java => The model class of the department*/
package com.department.model;


import java.util.List;

import org.json.JSONArray;

public class DepartmentModel {
	private String deptID;
	private String deptname;
	private String type;
	private String username;
	
	public String getDeptID() {
		return deptID;
	}
	public void setDeptID(String deptID) {
		this.deptID = deptID;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	private List<DepartmentModel>  DeptList;
	private JSONArray deptListJson;
	private String actionName;
	
	public List<DepartmentModel> getDeptList() {
		return DeptList;
	}

	public void setDeptList(List<DepartmentModel> deptList) {
		this.DeptList = deptList;
	}
	public JSONArray getDeptListJson() {
		return deptListJson;
	}

	public void setDeptListJson(JSONArray deptListJson) {
		this.deptListJson = deptListJson;
	}
	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	@Override
	public String toString() {
		return "DepartmentModel [deptID=" + deptID + ", deptname=" + deptname + "]";
	}
	
}
