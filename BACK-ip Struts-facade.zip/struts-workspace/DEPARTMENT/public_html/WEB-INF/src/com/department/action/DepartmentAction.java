/* DepartmentAction.java=>The  action class  goesto contoller */

package com.department.action;



import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.json.JSONArray;

import com.department.controller.DepartmentController;
import com.department.model.DepartmentModel;
import com.kott.ejbx.DepartmentModelValue;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class DepartmentAction   extends ActionSupport implements ModelDriven<DepartmentModel > ,SessionAware {

	private static final long serialVersionUID = 1L;
	DepartmentModel   model = new DepartmentModel ();
	DepartmentModelValue departmentModelValue = new DepartmentModelValue();
	DepartmentController   departmentController = new DepartmentController ();

	List<DepartmentModel>  DeptList; 
	private JSONArray deptListJson;
	String actionName;
	private Map<String, Object> session;

	/*to add page*/
	public String addPage()  {
		System.out.println(model.getUsername()+"---------");
		session.put("type", model.getType());
		session.put("username",model.getUsername());
		System.out.println(model.getUsername()+"---------");
		model.setActionName("ADD");
		return "success";
	}


	/* view Department */	
	public String view()  {
		deptListJson = departmentController.viewDeptCtrl(); 
		model.setDeptListJson(deptListJson);
		return "success";
	}

	/*Delete method*/
	public String delete() {
		departmentModelValue.setDeptID(model.getDeptID());
		departmentModelValue.setDeptname(model.getDeptname());
		String type = departmentController.deleteDeptCtrl(departmentModelValue);
		return type;
	}

	/*to EditPage*/
	public String editPage() {
		model.setActionName("EDIT");
		departmentModelValue.setDeptID(model.getDeptID());
		departmentModelValue.setDeptname(model.getDeptname());

		departmentModelValue =departmentController.deptobjCtrl(departmentModelValue.getDeptID());
		model.setDeptID(departmentModelValue.getDeptID());
		model.setDeptname(departmentModelValue.getDeptname());
		return "success";
	}

	/*actionEmp-ADD or Delete */
	public String actionEmp() {

		departmentModelValue.setDeptID(model.getDeptID());
		departmentModelValue.setDeptname(model.getDeptname());

		if(model.getActionName().equals("ADD")) { 

			String type = departmentController.addDeptCtrl(departmentModelValue);
			addActionMessage("The data inserted successfully"); 
			return type;
		}
		else if(model.getActionName().equals("EDIT")) {
			String type  = departmentController.editDeptCtrl(departmentModelValue);
			return type;
		}
		else {
			return "error";
		}

	}
	@Override
	public DepartmentModel getModel() {
		return model;
	}
	@Override
	public String execute() throws Exception {

		return null;
	}



	@Override
	public void setSession(Map<String, Object> session) {
		this.session =session;

	}



}


