package com.login.controller;

import com.login.model.LoginModel;

public class LoginController {

	public String validatelogin(LoginModel member) {
		System.out.println("hello -----------------------------------");
		System.out.println(member);
		return null;
	}

}
