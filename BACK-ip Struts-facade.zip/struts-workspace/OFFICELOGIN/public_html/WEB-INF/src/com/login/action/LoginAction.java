package com.login.action;

import com.login.controller.LoginController;
import com.login.model.LoginModel;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ModelDriven;

public class LoginAction implements Action, ModelDriven<LoginModel> {
	
	LoginModel member = new LoginModel();

	public LoginModel getModel() {
		System.out.println("in model method");
		return member;
	}

	public String execute() throws Exception {
		/*
		 * System.out.println("in execute"); LoginController v = new LoginController();
		 * String type = v.validatelogin(member); return type;
		 */
		return null;
	}

	public String login() throws Exception {
	
		System.out.println("in login method");
		return "A"; 
	}
}
