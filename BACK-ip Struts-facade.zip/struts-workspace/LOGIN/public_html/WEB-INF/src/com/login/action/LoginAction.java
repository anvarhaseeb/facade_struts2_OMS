/*LoginAction.java => It is the action class for Login and it goes to controller*/
package com.login.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kott.ejbx.EmployeeModelValue;
import com.kott.ejbx.LoginModelValue;
import com.login.controller.LoginController;
import com.login.model.EmployeeModel;
import com.login.model.LoginModel;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class LoginAction extends ActionSupport implements ModelDriven<LoginModel>, SessionAware,Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(LoginAction.class);
	LoginModel model = new LoginModel();
	LoginController loginController = new LoginController();
	LoginModelValue modelValue = new LoginModelValue();
	
	private Map<String, Object> session;

	/*Login method*/
	public String login() throws Exception {
		
		modelValue.setUsername(model.getUsername());
		modelValue.setPassword(model.getPassword());
		modelValue.setEmpid(model.getEmpid());
		LoginModelValue log =loginController.validatelogin(modelValue);
		
		if(log.getType().equals("invalid"))
		{
			addActionMessage("Username and password are incorrect");
		}
		logger.info(model.getUsername());

		model.setEmpid(modelValue.getEmpid());
		model.setUsername(model.getUsername());
		model.setType(modelValue.getType());
		
		/*To pass the profile datas*/

		List<EmployeeModelValue>  profileValueList = loginController.profileList(modelValue.getEmpid());
		List<EmployeeModel>  profileList = new ArrayList<>();
		profileValueList.forEach(x-> {
			
			EmployeeModel employeeModel = new EmployeeModel();
			employeeModel.setEmpid(x.getEmpid());
			employeeModel.setEmpname(x.getEmpname());
			employeeModel.setDob(x.getDob());
			employeeModel.setQualification(x.getQualification());
			employeeModel.setPhn(x.getPhn());
			employeeModel.setEmail(x.getEmail());
			employeeModel.setExp(x.getExp());
			employeeModel.setCmpname(x.getCmpname());
			employeeModel.setAddress(x.getAddress());
			employeeModel.setDoj(x.getDoj());
			employeeModel.setDept(x.getDept());
			profileList.add(employeeModel);
			
		});
		model.setProfileList(profileList);

		session.put("username", model.getUsername());
		session.put("empid", model.getEmpid());
		session.put("type", model.getType());

		return modelValue.getType();   

	}
	public String logout() {

		return "success";
	}

	public LoginAction() {

		model = new LoginModel(); 
	}
	@Override
	public void validate() {  
		if(model.getUsername() != null) {
		if (model.getUsername().isEmpty()) {  
			addFieldError("username", "Name can't be blank");
		}
		if (model.getPassword().length() < 2) {  
			addFieldError("password", "Password must be greater than 3");
		}
		}
	}

	@Override
	public LoginModel getModel() {
		return model;
	}
	@Override
	public String execute() throws Exception {
		return null;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;

	}
}
