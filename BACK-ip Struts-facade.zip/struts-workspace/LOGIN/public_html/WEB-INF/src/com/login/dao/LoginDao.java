/*
 * LoginDao.java =>Mainly used to check the type from LOGIN table and username
 * and password are exist or not package com.login.dao;
 * 
 * import java.sql.Connection; import java.sql.PreparedStatement; import
 * java.sql.ResultSet; import java.sql.SQLException; import java.util.ArrayList;
 * import java.util.List;
 * 
 * import com.login.model.EmployeeModel; import com.login.model.LoginModel;
 * import com.profile.dao.DBConnect; import com.profile.model.ProfileModel;
 * 
 * public class LoginDao { public LoginModel loginCheck(LoginModel user) {
 * 
 * Connection con = DBConnect.getConnection(); String sql =
 * "SELECT emp_id, username,password,type from LOGIN where username=? and password=?"
 * ; try { PreparedStatement ps = con.prepareStatement(sql);
 * 
 * 
 * ps.setString(1, user.getUsername()); ps.setString(2, user.getPassword());
 * ResultSet resultSet = ps.executeQuery();
 * 
 * if (resultSet.next()) { user.setType(resultSet.getString("type"));
 * user.setEmpid(resultSet.getInt("emp_id"));
 * user.setUsername(resultSet.getString("username"));
 * user.setPassword(resultSet.getString("password")); } return user; } catch
 * (SQLException e) { e.printStackTrace();
 * 
 * } return user; }
 * 
 * public List<EmployeeModel> profileList(int empid) {
 * 
 * Connection con = DBConnect.getConnection(); List<EmployeeModel>EmpList = new
 * ArrayList<EmployeeModel>();
 * 
 * String sql = "SELECT * FROM Employees WHERE empid = ?";
 * 
 * try { PreparedStatement ps = con.prepareStatement(sql); ps.setInt(1, empid);
 * ResultSet resultSet = ps.executeQuery();
 * 
 * if (resultSet.next()) { EmployeeModel employee = new EmployeeModel();
 * employee.setEmpid(resultSet.getInt("empid"));
 * employee.setEmpname(resultSet.getString("empname"));
 * employee.setDob(resultSet.getString("dob"));
 * employee.setQualification(resultSet.getString("qualification"));
 * employee.setPhn(resultSet.getString("phn"));
 * employee.setEmail(resultSet.getString("email"));
 * employee.setExp(resultSet.getInt("exp"));
 * employee.setCmpname(resultSet.getString("cmpname"));
 * employee.setAddress(resultSet.getString("address"));
 * employee.setDoj(resultSet.getString("doj"));
 * employee.setDept(resultSet.getString("dept")); EmpList.add(employee); return
 * EmpList; } } catch (SQLException e) { e.printStackTrace(); }
 * 
 * return null;
 * 
 * 
 * } }
 * 
 */