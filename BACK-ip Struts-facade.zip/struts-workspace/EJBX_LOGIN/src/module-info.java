/**
 * 
 */
/**
 * 
 */
module EJBX_LOGIN {
	requires java.sql;
}