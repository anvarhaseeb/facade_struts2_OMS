package com.kott.manager;

import java.util.List;

import com.kott.ejbx.EmployeeModelValue;
import com.kott.ejbx.LoginModelValue;

public interface FacadeManager {
	public LoginModelValue loginCheck(LoginModelValue user) ;
	public List<EmployeeModelValue> profileList(int empid);
}
