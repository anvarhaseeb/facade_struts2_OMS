package com.profile.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.kott.ejbx.ProfileModelValue;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import com.profile.controller.ProfileController;
import com.profile.model.ProfileModel;

public class ProfileAction extends ActionSupport implements ModelDriven<ProfileModel>, Preparable, SessionAware  {

	private static final long serialVersionUID = 1L;
	ProfileModel model;
	ProfileModelValue modelValue = new ProfileModelValue();
	ProfileController profileController = new ProfileController();
	private Map<String, Object> session;
	

	public String profile() {
		session.put("empid", model.getEmpid());
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getUsername());
		List<ProfileModelValue> empValueList = profileController.empListCtrl(modelValue.getEmpid());
		List<ProfileModel>EmpList = new ArrayList<ProfileModel>();
		
		empValueList.forEach(x -> {
			ProfileModel employeeModel = new ProfileModel();
			employeeModel.setEmpid(x.getEmpid());
			employeeModel.setEmpname(x.getEmpname());
			employeeModel.setDob(x.getDob());
			employeeModel.setQualification(x.getQualification());
			employeeModel.setPhn(x.getPhn());
			employeeModel.setEmail(x.getEmail());
			employeeModel.setExp(x.getExp());
			employeeModel.setCmpname(x.getCmpname());
			employeeModel.setAddress(x.getAddress());
			employeeModel.setDoj(x.getDoj());
			employeeModel.setDept(x.getDept());
			EmpList.add(employeeModel);
			
		}	);

		model.setEmpList(EmpList);
		model.setEmpid(modelValue.getEmpid());
		model.setUsername(modelValue.getUsername());

	
		return "success";

	}

	
	@Override
	public ProfileModel getModel() {
		return model;
	}

	@Override
	public void prepare() throws Exception {
		model = new ProfileModel();
		
	}
	@Override
	public String execute() throws Exception {
		return null;
	}

	@Override
	public void setSession(Map<String, Object> session) {
		this.session= session;
		
	}

}
