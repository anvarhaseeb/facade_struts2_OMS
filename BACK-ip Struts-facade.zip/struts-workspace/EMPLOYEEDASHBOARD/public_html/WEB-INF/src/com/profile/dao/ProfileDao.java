/*
 * package com.profile.dao;
 * 
 * import java.sql.Connection; import java.sql.PreparedStatement; import
 * java.sql.ResultSet; import java.sql.SQLException; import java.util.ArrayList;
 * import java.util.List; import com.profile.model.ProfileModel;
 * 
 * public class ProfileDao { static Connection con = DBConnect.getConnection();
 * List<ProfileModel>EmpList = new ArrayList<ProfileModel>();
 * 
 * public List<ProfileModel> empListShow(int empid) { String sql =
 * "SELECT * FROM Employees WHERE empid = ?";
 * 
 * try { PreparedStatement ps = con.prepareStatement(sql); ps.setInt(1, empid);
 * ResultSet resultSet = ps.executeQuery();
 * 
 * if (resultSet.next()) { ProfileModel employee = new ProfileModel();
 * employee.setEmpid(resultSet.getInt("empid"));
 * employee.setEmpname(resultSet.getString("empname"));
 * employee.setDob(resultSet.getString("dob"));
 * employee.setQualification(resultSet.getString("qualification"));
 * employee.setPhn(resultSet.getString("phn"));
 * employee.setEmail(resultSet.getString("email"));
 * employee.setExp(resultSet.getInt("exp"));
 * employee.setCmpname(resultSet.getString("cmpname"));
 * employee.setAddress(resultSet.getString("address"));
 * employee.setDoj(resultSet.getString("doj"));
 * employee.setDept(resultSet.getString("dept")); EmpList.add(employee); return
 * EmpList; } } catch (SQLException e) { e.printStackTrace(); }
 * 
 * return null;
 * 
 * }
 * 
 * }
 */