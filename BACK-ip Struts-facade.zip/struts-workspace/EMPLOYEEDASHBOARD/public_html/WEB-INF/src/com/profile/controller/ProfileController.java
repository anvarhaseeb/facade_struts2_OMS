
package com.profile.controller;

import java.util.ArrayList;
import java.util.List;

import com.kott.ejbx.ProfileModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;


public class ProfileController {
	List<ProfileModelValue>EmpList = new ArrayList<ProfileModelValue>();

	public List<ProfileModelValue> empListCtrl(int empid) {
		FacadeManager facade =new  FacadeManagerBean();
		EmpList = facade.empListShow(empid);
		return EmpList;
	}


}
