/**
 * 
 */
/**
 * 
 */
module EJBX_LEAVEEMP {
	requires java.sql;
}