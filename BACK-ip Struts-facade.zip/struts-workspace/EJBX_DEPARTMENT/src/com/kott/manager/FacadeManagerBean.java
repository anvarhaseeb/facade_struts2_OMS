package com.kott.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.kott.database.DBConnect;
import com.kott.ejbx.DepartmentModelValue;


public class FacadeManagerBean implements FacadeManager {
	Connection  con = DBConnect.getConnection();

	public String addDept(DepartmentModelValue modelValue) {
		String sql = "INSERT INTO Department (dept_id, dept_name) VALUES (?, ?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, modelValue.getDeptID());
			ps.setString(2, modelValue.getDeptname());
			int rowsInserted = ps.executeUpdate();
			if (rowsInserted > 0) {
				return "success";
			} else {

			}

		} catch (SQLException e) {
			e.printStackTrace(); 
			return "error";
		}
		return "success";
	}


	public List<DepartmentModelValue> viewDept() {
		List<DepartmentModelValue> DeptList= new ArrayList<>();
		String sql = "SELECT  *from Department";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet resultSet = ps.executeQuery();

			while (resultSet.next()) {
				String dptid= resultSet.getString("dept_id");
				String dptname= resultSet.getString("dept_name");

				DepartmentModelValue d =new DepartmentModelValue();
				d.setDeptID(dptid);
				d.setDeptname(dptname);

				DeptList.add(d);
			}

		} catch (SQLException e) {
			e.printStackTrace(); 

		} 

		return DeptList;
	}


	public String deleteDept(DepartmentModelValue modelValue) {
		String sql = "DELETE FROM Department WHERE  dept_id = ?";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, modelValue.getDeptID());

			int rowsDeleted = ps.executeUpdate();
			if (rowsDeleted > 0) {
				return "success";
			} else {
				return "error";
			}

		} catch (SQLException e) {
			e.printStackTrace(); 
			return "error";
		}
	}

	public List<DepartmentModelValue> editPageList(DepartmentModelValue modelValue) {

		List<DepartmentModelValue> DeptList= new ArrayList<>();
		String sql = "SELECT  *from Department where dept_id = ? ";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, modelValue.getDeptID());
			ResultSet resultSet = ps.executeQuery();

			while (resultSet.next()) {
				String dptid= resultSet.getString("dept_id");
				String dptname= resultSet.getString("dept_name");

				DepartmentModelValue d =new DepartmentModelValue();
				d.setDeptID(dptid);
				d.setDeptname(dptname);

				DeptList.add(d);
			}
			con.close();
		} catch (SQLException e) {
			e.printStackTrace(); 

		} 
		return DeptList;
	}


	public String editDept(DepartmentModelValue modelValue) {
		String sql = "UPDATE Department SET  dept_name = ? WHERE dept_id = ?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, modelValue.getDeptname());
			ps.setString(2, modelValue.getDeptID());

			int rowsUpdated = ps.executeUpdate();
			if (rowsUpdated > 0) {

				return "success";
			} else {

				return "error";
			}
		} catch (SQLException e) {
			e.printStackTrace(); 
			return "error";
		}
	}


	public DepartmentModelValue deoptObj(String deptID) {
		String sql = "SELECT  *from Department where dept_id=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, deptID);

			ResultSet resultSet = ps.executeQuery();
			while (resultSet.next()) {
				String dptid= resultSet.getString("dept_id");
				String dptname= resultSet.getString("dept_name");
				DepartmentModelValue dept =new DepartmentModelValue();
				dept.setDeptID(dptid);
				dept.setDeptname(dptname);

				return dept;
			}

		} catch (SQLException e) {
			e.printStackTrace(); 
		} 
		return null;
	}
}