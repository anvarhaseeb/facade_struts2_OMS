/*DepartmenrModeValuel.java => The model class of the department*/
package com.kott.ejbx;


import java.util.List;


public class DepartmentModelValue {
	private String deptID;
	private String deptname;
	private String type;
	private String username;
	
	public String getDeptID() {
		return deptID;
	}
	public void setDeptID(String deptID) {
		this.deptID = deptID;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	private List<DepartmentModelValue>  DeptList;
	private String actionName;
	
	public List<DepartmentModelValue> getDeptList() {
		return DeptList;
	}

	public void setDeptList(List<DepartmentModelValue> deptList) {
		this.DeptList = deptList;
	}
	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	@Override
	public String toString() {
		return "DepartmentModel [deptID=" + deptID + ", deptname=" + deptname + "]";
	}
	
}
