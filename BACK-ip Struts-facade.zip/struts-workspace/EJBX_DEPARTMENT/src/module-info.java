/**
 * 
 */
/**
 * 
 */
module EJBX_DEPARTMENT {
	requires java.sql;
}