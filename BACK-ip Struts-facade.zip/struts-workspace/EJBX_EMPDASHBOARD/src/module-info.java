/**
 * 
 */
/**
 * 
 */
module EJBX_EMPDASHBOARD {
	requires java.sql;
}