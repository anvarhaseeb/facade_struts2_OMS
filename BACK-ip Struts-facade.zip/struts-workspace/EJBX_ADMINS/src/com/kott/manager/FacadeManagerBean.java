package com.kott.manager;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.kott.database.DBConnect;
import com.kott.ejbx.DepartmentModelValue;
import com.kott.ejbx.EmployeeModelValue;



public class FacadeManagerBean implements FacadeManager {
	static Connection  con = DBConnect.getConnection();
	public List<DepartmentModelValue> viewDept() {
		List<DepartmentModelValue> DeptList= new ArrayList<>();
		String sql = "SELECT  *from Department";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet resultSet = ps.executeQuery();

			while (resultSet.next()) {
				String dptid= resultSet.getString("dept_id");
				String dptname= resultSet.getString("dept_name");

				DepartmentModelValue d =new DepartmentModelValue();
				d.setDeptID(dptid);
				d.setDeptname(dptname);

				DeptList.add(d);
			}
			
		} catch (SQLException e) {
			e.printStackTrace(); 
			System.out.println("exception in view AdminDept dep :{--");
		} 

		return DeptList;
	}


	public String addEmp(EmployeeModelValue model) {
		String sql = "INSERT INTO Employees (empname, dob, qualification, phn, email, exp, cmpname, address, doj, dept) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try {

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, model.getEmpname());
			ps.setString(2, model.getDob()); 
			ps.setString(3, model.getQualification());
			ps.setString(4, model.getPhn());
			ps.setString(5, model.getEmail());
			ps.setInt(6, model.getExp());
			ps.setString(7, model.getCmpname());
			ps.setString(8, model.getAddress());
			ps.setString(9, model.getDoj()); 
			ps.setString(10, model.getDept());

			int rowsInserted = ps.executeUpdate();

			if (rowsInserted > 0) {

				return "success";
			} else {

				return "error";
			}
		} catch (SQLException e) {

			e.printStackTrace();
			return "error";
		}

	}

	public List<EmployeeModelValue> searchEmp(EmployeeModelValue model) {
		List<EmployeeModelValue> empList = new ArrayList<>();
		try {
			StringBuilder sql = new StringBuilder("SELECT * FROM Employees WHERE 1=1");
			int parameterIndex = 1;

			if (model.getEmpid() != 0) {
				sql.append(" AND empid LIKE ?");
			}
			if (model.getEmpname() != null && !model.getEmpname().isEmpty()) {
				sql.append(" AND empname LIKE ?");
			}

			if (model.getDob() != null) {
				sql.append(" AND dob = ?");
			}

			if (model.getQualification() != null && !model.getQualification().isEmpty()) {
				sql.append(" AND qualification LIKE ?");
			}
			if (model.getPhn() != null && !model.getPhn().isEmpty()) {
				sql.append(" AND phn LIKE ?");
			}
			if (model.getEmail() != null && !model.getEmail().isEmpty()) {
				sql.append(" AND email LIKE ?");
			}
			if (model.getExp()  != 0) {
				sql.append(" AND exp = ?");
			}
			if (model.getCmpname() != null && !model.getCmpname().isEmpty()) {
				sql.append(" AND cmpname LIKE ?");
			}
			if (model.getAddress() != null && !model.getAddress().isEmpty()) {
				sql.append(" AND address LIKE ?");
			}
			if (model.getDoj() != null) {
				sql.append(" AND doj = ?");
			}
			if (model.getDept() != null && !model.getDept().isEmpty()) {
				sql.append(" AND dept LIKE ?");
			}

			PreparedStatement ps = con.prepareStatement(sql.toString());

			if (model.getEmpid() != 0) {
				ps.setString(parameterIndex++, "%" + model.getEmpid() + "%");
			}
			if (model.getEmpname() != null && !model.getEmpname().isEmpty()) {
				ps.setString(parameterIndex++, "%" + model.getEmpname() + "%");
			}
			if (model.getDob() != null) {
				ps.setString(parameterIndex++, model.getDob());
			}
			if (model.getQualification() != null && !model.getQualification().isEmpty()) {
				ps.setString(parameterIndex++, "%" + model.getQualification() + "%");
			}
			if (model.getPhn() != null && !model.getPhn().isEmpty()) {
				ps.setString(parameterIndex++, "%" + model.getPhn() + "%");
			}
			if (model.getEmail() != null && !model.getEmail().isEmpty()) {
				ps.setString(parameterIndex++, "%" + model.getEmail() + "%");
			}
			if (model.getExp()  != 0) {
				ps.setInt(parameterIndex++, model.getExp());
			}
			if (model.getCmpname() != null && !model.getCmpname().isEmpty()) {
				ps.setString(parameterIndex++, "%" + model.getCmpname() + "%");
			}
			if (model.getAddress() != null && !model.getAddress().isEmpty()) {
				ps.setString(parameterIndex++, "%" + model.getAddress() + "%");
			}
			if (model.getDoj() != null) {
				ps.setString(parameterIndex++, model.getDoj());
			}
			if (model.getDept() != null && !model.getDept().isEmpty()) {
				ps.setString(parameterIndex, "%" + model.getDept() + "%");
			}

			ResultSet resultSet = ps.executeQuery();

			while (resultSet.next()) {
				EmployeeModelValue employee = new EmployeeModelValue();
				employee.setEmpid(resultSet.getInt("empid"));
				employee.setEmpname(resultSet.getString("empname"));
				employee.setDob(resultSet.getString("dob"));
				employee.setQualification(resultSet.getString("qualification"));
				employee.setPhn(resultSet.getString("phn"));
				employee.setEmail(resultSet.getString("email"));
				employee.setExp(resultSet.getInt("exp"));
				employee.setCmpname(resultSet.getString("cmpname"));
				employee.setAddress(resultSet.getString("address"));
				employee.setDoj(resultSet.getString("doj"));
				employee.setDept(resultSet.getString("dept"));

				empList.add(employee);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}

		return empList;
	}

	public String deleteEmp(EmployeeModelValue model) {
		if ("Admin".equals(model.getEmpname())) {

			return "cannotDelete";
		}
		String sql1 = "Delete from Employees where empid = ?";
		String sql2 = "Delete from LOGIN where emp_id = ?";
		try {
			PreparedStatement ps1 = con.prepareStatement(sql1);
			ps1.setInt(1,model.getEmpid());


			PreparedStatement ps2 = con.prepareStatement(sql2);
			ps2.setInt(1,model.getEmpid());


			int rowEmpDeleted = ps1.executeUpdate();
			int rowLogDeleted = ps2.executeUpdate();

			if(rowEmpDeleted > 0 || rowLogDeleted > 0) {

				return "success";
			} else {
				return "error";
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return "success";
	}

	public String editEmp(EmployeeModelValue model) {


		String sql = "UPDATE Employees SET empname = ?, dob = ?, qualification = ?, phn = ?, email = ?, exp = ?, cmpname = ?, address = ?, doj = ?, dept = ? WHERE empid = ?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, model.getEmpname());
			ps.setString(2, model.getDob());
			ps.setString(3, model.getQualification());
			ps.setString(4, model.getPhn());
			ps.setString(5, model.getEmail());
			ps.setInt(6, model.getExp());
			ps.setString(7, model.getCmpname());
			ps.setString(8, model.getAddress());
			ps.setString(9, model.getDoj());
			ps.setString(10, model.getDept());
			ps.setInt(11, model.getEmpid());

			int rowsUpdated = ps.executeUpdate();

			if (rowsUpdated > 0) {

				return "success";
			} else {

				return "error";
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return "error";
		}

	}

	public EmployeeModelValue showEmp(int empid) {
		String sql = "SELECT * FROM Employees WHERE empid = ?";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, empid);  
			ResultSet resultSet = ps.executeQuery();

			if (resultSet.next()) {
				EmployeeModelValue employee = new EmployeeModelValue();
				employee.setEmpid(resultSet.getInt("empid"));
				employee.setEmpname(resultSet.getString("empname"));
				employee.setDob(resultSet.getString("dob"));
				employee.setQualification(resultSet.getString("qualification"));
				employee.setPhn(resultSet.getString("phn"));
				employee.setEmail(resultSet.getString("email"));
				employee.setExp(resultSet.getInt("exp"));
				employee.setCmpname(resultSet.getString("cmpname"));
				employee.setAddress(resultSet.getString("address"));
				employee.setDoj(resultSet.getString("doj"));
				employee.setDept(resultSet.getString("dept"));

				return employee;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}


		return null;  
	}

}
