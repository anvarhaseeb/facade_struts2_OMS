package com.kott.manager;

import java.util.List;

import com.kott.ejbx.DepartmentModelValue;
import com.kott.ejbx.EmployeeModelValue;

public interface FacadeManager {
	
	public List<DepartmentModelValue> viewDept() ;
	public String addEmp(EmployeeModelValue model) ;
	public List<EmployeeModelValue> searchEmp(EmployeeModelValue model) ;
	public String deleteEmp(EmployeeModelValue model) ;
	public String editEmp(EmployeeModelValue model) ;
	public EmployeeModelValue showEmp(int empid) ;
	
	
}
