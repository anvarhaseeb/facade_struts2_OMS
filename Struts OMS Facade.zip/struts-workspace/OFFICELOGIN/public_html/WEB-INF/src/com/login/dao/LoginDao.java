package com.login.dao;

public class LoginDao {

}
