/*LoginDao.java =>Mainly used to check the type from LOGIN table and username and password are exist or not*/
package com.kott.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.kott.database.DBConnect;
import com.kott.ejbx.EmployeeModelValue;
import com.kott.ejbx.LoginModelValue;


public class FacadeManagerBean  implements FacadeManager {
	public LoginModelValue loginCheck(LoginModelValue user) {
		try (Connection con = DBConnect.getConnection();
				PreparedStatement ps = con.prepareStatement("SELECT emp_id, username, password, type FROM LOGIN WHERE username = ? AND password = ?")) {

			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			try (ResultSet resultSet = ps.executeQuery()) {
				if (resultSet.next()) {
					user.setType(resultSet.getString("type"));
					user.setEmpid(resultSet.getInt("emp_id"));
					user.setUsername(resultSet.getString("username"));
					user.setPassword(resultSet.getString("password"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

	public List<EmployeeModelValue> profileList(int empid) {
		try (Connection con = DBConnect.getConnection();
				PreparedStatement ps = con.prepareStatement("SELECT * FROM Employees WHERE empid = ?")) {

			ps.setInt(1, empid);
			try (ResultSet resultSet = ps.executeQuery()) {
				if (resultSet.next()) {
					List<EmployeeModelValue> EmpList = new ArrayList<EmployeeModelValue>();
					EmployeeModelValue employee = new EmployeeModelValue();
					employee.setEmpid(resultSet.getInt("empid"));
					employee.setEmpname(resultSet.getString("empname"));
					employee.setDob(resultSet.getString("dob"));
					employee.setQualification(resultSet.getString("qualification"));
					employee.setPhn(resultSet.getString("phn"));
					employee.setEmail(resultSet.getString("email"));
					employee.setExp(resultSet.getInt("exp"));
					employee.setCmpname(resultSet.getString("cmpname"));
					employee.setAddress(resultSet.getString("address"));
					employee.setDoj(resultSet.getString("doj"));
					employee.setDept(resultSet.getString("dept"));
					EmpList.add(employee);
					return EmpList;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

}

