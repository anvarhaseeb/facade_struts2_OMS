package com.employeeusername.action;

import java.io.Serializable;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.json.JSONArray;

import com.employeeusername.controller.EmpLogCreateController;
import com.employeeusername.model.EmpLogCreateModel;
import com.kott.ejbx.EmpLogCreateModelValue;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import com.opensymphony.xwork2.interceptor.ValidationAware;

public class EmpLogCreateAction extends ActionSupport implements ModelDriven<EmpLogCreateModel>, ValidationAware,Preparable, SessionAware, Serializable {

	private static final long serialVersionUID = 1L;
	private transient EmpLogCreateModel model ;
	private transient Map<String, Object> session;
	private transient  EmpLogCreateModelValue modelValue ;
	private transient  EmpLogCreateController empLogController ;


	public boolean validLogin() {
		if (model.getEmpid() == 0) {
			addFieldError("model.empid", "Empid can't be ZERO");
			return false;
		}
		String username = model.getUsername();
		if (username == null || username.isEmpty()) {
			addFieldError("model.username", "Name can't be blank");

			return false;
		}

		String password = model.getPassword();
		if (password == null || password.length() < 3) {
			addFieldError("model.password", "Password must be greater than 3 characters");
			return false;
		}

		String type = model.getType();
		if (type == null || type.isEmpty()) {
			addFieldError("model.type", "Type can't be blank");
			return false;
		}
		else {

			return true;
		}
	}


	public String viewUnamePass()  {

		JSONArray logListJson = empLogController.viewLogtCtrl(); 
		model.setLogListJson(logListJson);
		return SUCCESS;
	}

	public String deleteLog(){

		modelValue.setEmpid(model.getEmpid());
		String type = empLogController.deleteLogCtrl(modelValue.getEmpid()); 
		model.setActionMessages("Deleted");
		return type;
	}
	/*addPage - {From ADMINS module}when clicking into employeedata's empid, it will go to this method*/
	public String addPage() {
		if (model.getUsernames() != null) {
			session.put("username", model.getUsernames());
			session.put("empid", model.getEmpid());
		}
		model.setActionName("ADD");
		return  SUCCESS;
	}
	public String editPage() {
		model.setActionName("EDIT");
		modelValue.setEmpid(model.getEmpid());
		modelValue =empLogController.emploglistCtrl(modelValue.getEmpid());

		model.setEmpid(modelValue.getEmpid());
		model.setUsernames(modelValue.getUsernames());
		model.setUsername(modelValue.getUsername());
		model.setPassword(modelValue.getPassword());
		model.setType(modelValue.getType());
		return  SUCCESS;
	}

	public String actionLog() {

		if(!validLogin()) {	
			return "input";
		}
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getUsername());
		modelValue.setPassword(model.getPassword());
		modelValue.setType(model.getType());

		if(model.getActionName().equals("ADD")) {

			String type=empLogController.addLogCtrl(modelValue);
			if(type.equals("duplicate")) {
				addActionError("The username or empid   already exist"); 
				return "input";
			}
			model.setActionMessages("added"); 

			return type;
		}
		else if(model.getActionName().equals("EDIT")) {

			String type=empLogController.editLogCtrl(modelValue);
			model.setActionMessages("edited");

			return type;
		}
		else {
			return "error";
		}

	}

	@Override
	public String execute() {
		return null;
	}
	@Override
	public EmpLogCreateModel getModel() {

		return model;
	}


	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}


	@Override
	public void prepare() throws Exception {
		model =new EmpLogCreateModel();
		modelValue = new EmpLogCreateModelValue();
		empLogController = new EmpLogCreateController();
	}

}
