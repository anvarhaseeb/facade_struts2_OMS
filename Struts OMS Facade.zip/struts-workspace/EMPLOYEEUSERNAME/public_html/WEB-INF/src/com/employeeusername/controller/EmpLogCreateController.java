/*The EMPLOYEEUSERNAME module :  EmpLogController =>Act as bridge between action class and dao*/
package com.employeeusername.controller;

import java.util.List;

import org.json.JSONArray;


import com.kott.ejbx.EmpLogCreateModelValue;
import com.kott.manager.FacadeManagerBean;
import com.kott.manager.FacadeManager;


public class EmpLogCreateController{
	EmpLogCreateModelValue modelValue = new EmpLogCreateModelValue();
	FacadeManager facade =new FacadeManagerBean();

	/*View Login credentials,like username password and type*/
	public  JSONArray viewLogtCtrl() {

		List<EmpLogCreateModelValue> logList= facade.viewLog();
		return  new JSONArray(logList);
	}
	/*Delete Login method*/
	public  String deleteLogCtrl(int empid) {
		return facade.delete(empid);
	}

	/*add login credentials and check the duplicate of username and empid or not*/
	public  String addLogCtrl(EmpLogCreateModelValue modelValue) {

		boolean condition = facade.checkuname(modelValue.getUsername(),modelValue.getEmpid());
		if(condition) {
			return "duplicate";
		}
		else {
			return facade.addLog(modelValue);

		}
	}
	/*Edit Login method*/
	public  String editLogCtrl(EmpLogCreateModelValue modelValue) {

		return facade.editLog(modelValue);

	}
	/*to retrieve object of  Login to display values in text-field in edit Page*/
	public  EmpLogCreateModelValue emploglistCtrl(int empid) {

		return facade.emplogListempid(empid);
	}

}
