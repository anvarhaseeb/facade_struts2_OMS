package com.kott.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.kott.database.DBConnect;
import com.kott.ejbx.DepartmentModelValue;
import com.kott.ejbx.EmployeeModelValue;

public class FacadeManagerBean implements FacadeManager {
	private static final String SUCCESS = "success";
	private static final String ERROR = "error";
	static Connection  con = DBConnect.getConnection();
	
	public List<DepartmentModelValue> viewDept() {
	    List<DepartmentModelValue> deptList = new ArrayList<>();
	    String sql = "SELECT * FROM Department";

	    try (PreparedStatement ps = con.prepareStatement(sql);
	         ResultSet resultSet = ps.executeQuery()) {
	        while (resultSet.next()) {
	            String dptid = resultSet.getString("dept_id");
	            String dptname = resultSet.getString("dept_name");

	            DepartmentModelValue d = new DepartmentModelValue();
	            d.setDeptID(dptid);
	            d.setDeptname(dptname);

	            deptList.add(d);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return deptList;
	}



	public String addEmp(EmployeeModelValue model) {
	    String sql = "INSERT INTO Employees (empname, dob, qualification, phn, email, exp, cmpname, address, doj, dept) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	    try (PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setString(1, model.getEmpname());
	        ps.setString(2, model.getDob());
	        ps.setString(3, model.getQualification());
	        ps.setString(4, model.getPhn());
	        ps.setString(5, model.getEmail());
	        ps.setInt(6, model.getExp());
	        ps.setString(7, model.getCmpname());
	        ps.setString(8, model.getAddress());
	        ps.setString(9, model.getDoj());
	        ps.setString(10, model.getDept());

	        int rowsInserted = ps.executeUpdate();

	        if (rowsInserted > 0) {
	            return SUCCESS;
	        } else {
	            return ERROR;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return ERROR;
	    }
	}


	public List<EmployeeModelValue> searchEmp(EmployeeModelValue model) {
	    List<EmployeeModelValue> empList = new ArrayList<>();

	    try {
	        StringBuilder sql = new StringBuilder("SELECT * FROM Employees WHERE 1=1");
	        int parameterIndex = 1;

	        if (model.getEmpid() != 0) {
	            sql.append(" AND empid LIKE ?");
	        }
	        if (isNotEmpty(model.getEmpname())) {
	            sql.append(" AND empname LIKE ?");
	        }
	        if (model.getDob() != null) {
	            sql.append(" AND dob = ?");
	        }
	        if (isNotEmpty(model.getQualification())) {
	            sql.append(" AND qualification LIKE ?");
	        }
	        if (isNotEmpty(model.getPhn())) {
	            sql.append(" AND phn LIKE ?");
	        }
	        if (isNotEmpty(model.getEmail())) {
	            sql.append(" AND email LIKE ?");
	        }
	        if (model.getExp() != 0) {
	            sql.append(" AND exp = ?");
	        }
	        if (isNotEmpty(model.getCmpname())) {
	            sql.append(" AND cmpname LIKE ?");
	        }
	        if (isNotEmpty(model.getAddress())) {
	            sql.append(" AND address LIKE ?");
	        }
	        if (model.getDoj() != null) {
	            sql.append(" AND doj = ?");
	        }
	        if (isNotEmpty(model.getDept())) {
	            sql.append(" AND dept LIKE ?");
	        }

	        try (PreparedStatement ps = con.prepareStatement(sql.toString())) {
	            if (model.getEmpid() != 0) {
	                ps.setString(parameterIndex++, "%" + model.getEmpid() + "%");
	            }
	            if (isNotEmpty(model.getEmpname())) {
	                ps.setString(parameterIndex++, "%" + model.getEmpname() + "%");
	            }
	            if (model.getDob() != null) {
	                ps.setString(parameterIndex++, model.getDob());
	            }
	            if (isNotEmpty(model.getQualification())) {
	                ps.setString(parameterIndex++, "%" + model.getQualification() + "%");
	            }
	            if (isNotEmpty(model.getPhn())) {
	                ps.setString(parameterIndex++, "%" + model.getPhn() + "%");
	            }
	            if (isNotEmpty(model.getEmail())) {
	                ps.setString(parameterIndex++, "%" + model.getEmail() + "%");
	            }
	            if (model.getExp() != 0) {
	                ps.setInt(parameterIndex++, model.getExp());
	            }
	            if (isNotEmpty(model.getCmpname())) {
	                ps.setString(parameterIndex++, "%" + model.getCmpname() + "%");
	            }
	            if (isNotEmpty(model.getAddress())) {
	                ps.setString(parameterIndex++, "%" + model.getAddress() + "%");
	            }
	            if (model.getDoj() != null) {
	                ps.setString(parameterIndex++, model.getDoj());
	            }
	            if (isNotEmpty(model.getDept())) {
	                ps.setString(parameterIndex, "%" + model.getDept() + "%");
	            }

	            try (ResultSet resultSet = ps.executeQuery()) {
	                while (resultSet.next()) {
	                    EmployeeModelValue employee = new EmployeeModelValue();
	                    employee.setEmpid(resultSet.getInt("empid"));
	                    employee.setEmpname(resultSet.getString("empname"));
	                    employee.setDob(resultSet.getString("dob"));
	                    employee.setQualification(resultSet.getString("qualification"));
	                    employee.setPhn(resultSet.getString("phn"));
	                    employee.setEmail(resultSet.getString("email"));
	                    employee.setExp(resultSet.getInt("exp"));
	                    employee.setCmpname(resultSet.getString("cmpname"));
	                    employee.setAddress(resultSet.getString("address"));
	                    employee.setDoj(resultSet.getString("doj"));
	                    employee.setDept(resultSet.getString("dept"));

	                    empList.add(employee);
	                }
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return empList;
	}

	private boolean isNotEmpty(String str) {
	    return str != null && !str.isEmpty();
	}

	public String deleteEmp(EmployeeModelValue model) {
	    if ("Admin".equals(model.getEmpname())) {
	        return "cannotDelete";
	    }
	    
	    String sql1 = "Delete from Employees where empid = ?";
	    String sql2 = "Delete from LOGIN where emp_id = ?";
	    
	    try (PreparedStatement ps1 = con.prepareStatement(sql1);
	         PreparedStatement ps2 = con.prepareStatement(sql2)) {
	        
	        ps1.setInt(1, model.getEmpid());
	        ps2.setInt(1, model.getEmpid());
	        
	        int rowEmpDeleted = ps1.executeUpdate();
	        int rowLogDeleted = ps2.executeUpdate();

	        if (rowEmpDeleted > 0 || rowLogDeleted > 0) {
	            return SUCCESS;
	        } else {
	            return ERROR;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return ERROR;
	}


	public String editEmp(EmployeeModelValue model) {
	    String sql = "UPDATE Employees SET empname = ?, dob = ?, qualification = ?, phn = ?, email = ?, exp = ?, cmpname = ?, address = ?, doj = ?, dept = ? WHERE empid = ?";
	    try (PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setString(1, model.getEmpname());
	        ps.setString(2, model.getDob());
	        ps.setString(3, model.getQualification());
	        ps.setString(4, model.getPhn());
	        ps.setString(5, model.getEmail());
	        ps.setInt(6, model.getExp());
	        ps.setString(7, model.getCmpname());
	        ps.setString(8, model.getAddress());
	        ps.setString(9, model.getDoj());
	        ps.setString(10, model.getDept());
	        ps.setInt(11, model.getEmpid());

	        int rowsUpdated = ps.executeUpdate();
	        if (rowsUpdated > 0) {
	            return SUCCESS;
	        } else {
	            return ERROR;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return ERROR;
	    }
	}


	public EmployeeModelValue showEmp(int empid) {
	    String sql = "SELECT * FROM Employees WHERE empid = ?";

	    try (PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, empid);
	        ResultSet resultSet = ps.executeQuery();

	        if (resultSet.next()) {
	            EmployeeModelValue employee = new EmployeeModelValue();
	            employee.setEmpid(resultSet.getInt("empid"));
	            employee.setEmpname(resultSet.getString("empname"));
	            employee.setDob(resultSet.getString("dob"));
	            employee.setQualification(resultSet.getString("qualification"));
	            employee.setPhn(resultSet.getString("phn"));
	            employee.setEmail(resultSet.getString("email"));
	            employee.setExp(resultSet.getInt("exp"));
	            employee.setCmpname(resultSet.getString("cmpname"));
	            employee.setAddress(resultSet.getString("address"));
	            employee.setDoj(resultSet.getString("doj"));
	            employee.setDept(resultSet.getString("dept"));
	            return employee;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null;
	}

}
