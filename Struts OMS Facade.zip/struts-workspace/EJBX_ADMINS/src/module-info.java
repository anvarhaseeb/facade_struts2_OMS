/**
 * 
 */
/**
 * 
 */
module EJBX_ADMINS {
	requires java.sql;
}