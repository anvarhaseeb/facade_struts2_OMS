package com.kott.manager;

import java.util.List;

import com.kott.ejbx.LeaveModelValue;

public interface FacadeManager {
	public String applyleave(LeaveModelValue modelValue) ;
	public List<LeaveModelValue> leaveStatus(int empid) ;
	public List<LeaveModelValue> leaveStatusAdmin() ;
	public String approveLeave(int leaveId) ;
	public String denyLeave(int leaveId) ;
	public String deleteLeave(int leaveId) ;
	public List<LeaveModelValue> leaveSearches(int empid2) ;
	public List<LeaveModelValue> empLists() ;
}
