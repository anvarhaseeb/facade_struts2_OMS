/*FacadeManagerBean.java=> It is for Leave Module. The methods in this class are applyLeave ,leaveStatus ,leaveStatusAdmin ,approveLeave, denyLeave ,and deleteLeave*/
package com.kott.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.kott.database.DBConnect;
import com.kott.ejbx.LeaveModelValue;

public class FacadeManagerBean implements FacadeManager {
	private static final String SUCCESS = "success";
	private static final String ERROR = "error";
	private static final String LEAVE_ID = "LeaveId";
	private static final String EMPID = "empid";
	private static final String EMPNAME = "empname";
	private static final String FROMDATE  = "fromdate";
	private static final String TODATE = "todate";
	private static final String LEAVETYPE  = "leavetype";
	private static final String REASON = "reason";
	private static final String STATUS = "status";



	/*Employee - Leave Apply*/
	public String applyleave(LeaveModelValue modelValue) {
		try (Connection con = DBConnect.getConnection()) {
			String sql = "INSERT INTO Leave (empid, fromdate, todate, leavetype, reason, status) VALUES (?, ?, ?, ?, ?, ?)";

			try (PreparedStatement ps = con.prepareStatement(sql)) {
				ps.setInt(1, modelValue.getEmpid());
				ps.setString(2, modelValue.getFromdate());
				ps.setString(3, modelValue.getTodate());
				ps.setString(4, modelValue.getLeavetype());
				ps.setString(5, modelValue.getReason());
				ps.setString(6, "pending");
				int rowsInserted = ps.executeUpdate();

				if (rowsInserted > 0) {
					return SUCCESS;
				} else {
					return ERROR;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return ERROR;
		}
	}


	/*Employee - Leave Status*/
	public List<LeaveModelValue> leaveStatus(int empid) {
		List<LeaveModelValue> leaveList = new ArrayList<>();

		try (Connection con = DBConnect.getConnection()) {
			String sql = "SELECT * FROM Leave where empid=?";
			try (PreparedStatement ps = con.prepareStatement(sql)) {
				ps.setInt(1, empid);

				try (ResultSet resultSet = ps.executeQuery()) {
					while (resultSet.next()) {
						int leaveId = resultSet.getInt(LEAVE_ID);
						String fromdate = resultSet.getString(FROMDATE  );
						String todate = resultSet.getString(TODATE );
						String leavetype = resultSet.getString(LEAVETYPE  );
						String reason = resultSet.getString(REASON );
						String status = resultSet.getString(STATUS );

						LeaveModelValue leave = new LeaveModelValue();
						leave.setLeaveId(leaveId);
						leave.setEmpid(empid);
						leave.setFromdate(fromdate);
						leave.setTodate(todate);
						leave.setLeavetype(leavetype);
						leave.setReason(reason);
						leave.setStatus(status);

						leaveList.add(leave);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return leaveList;
	}


	/*Admin - Leave Status*/
	public List<LeaveModelValue> leaveStatusAdmin() {
		List<LeaveModelValue> leaveList = new ArrayList<>();

		try (Connection con = DBConnect.getConnection()) {
			String sql = "SELECT Leave.LeaveId, Leave.empid, Employees.empname, Leave.fromdate, Leave.todate, Leave.leavetype, Leave.reason, Leave.status " +
					"FROM Leave " +
					"LEFT JOIN Employees ON Leave.empid = Employees.empid";

			try (PreparedStatement ps = con.prepareStatement(sql); ResultSet resultSet = ps.executeQuery()) {
				while (resultSet.next()) {
					Integer leaveId = resultSet.getInt(LEAVE_ID );
					Integer empid = resultSet.getInt(EMPID );
					String empname = resultSet.getString(EMPNAME );
					String fromdate = resultSet.getString(FROMDATE  );
					String todate = resultSet.getString(TODATE );
					String leavetype = resultSet.getString(LEAVETYPE );
					String reason = resultSet.getString(REASON );
					String status = resultSet.getString(STATUS );

					LeaveModelValue leave = new LeaveModelValue();
					leave.setLeaveId(leaveId);
					leave.setEmpid(empid);
					leave.setEmpname(empname);
					leave.setFromdate(fromdate);
					leave.setTodate(todate);
					leave.setLeavetype(leavetype);
					leave.setReason(reason);
					leave.setStatus(status);

					leaveList.add(leave);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return leaveList;
	}

	/*Admin can approve Leave*/
	public String approveLeave(int leaveId) {
		try (Connection con = DBConnect.getConnection();
				PreparedStatement ps = con.prepareStatement("UPDATE Leave SET status = 'approved' WHERE LeaveId = ?")) {
			ps.setInt(1, leaveId);

			int rowsUpdated = ps.executeUpdate();

			if (rowsUpdated > 0) {
				return SUCCESS;
			} else {
				return ERROR;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return ERROR;
		}
	}

	/*Admin can denyLeave*/
	public String denyLeave(int leaveId) {
		try (Connection con = DBConnect.getConnection();
				PreparedStatement ps = con.prepareStatement("UPDATE Leave SET status = 'rejected' WHERE LeaveId = ?")) {

			ps.setInt(1, leaveId);

			int rowsUpdated = ps.executeUpdate();

			if (rowsUpdated > 0) {
				return SUCCESS;
			} else {
				return ERROR;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return ERROR;
		}
	}

	/*Employee can delete Leave*/
	public String deleteLeave(int leaveId) {
		try (Connection con = DBConnect.getConnection();
				PreparedStatement ps = con.prepareStatement("DELETE FROM Leave WHERE LeaveId = ?")) {
			ps.setInt(1, leaveId);
			int rowsUpdated = ps.executeUpdate();

			if (rowsUpdated > 0) {
				return SUCCESS;
			} else {
				return ERROR;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return ERROR;
		}
	}

	/*Admin set of employees List name and empid*/
	public List<LeaveModelValue> empLists() {
		List<LeaveModelValue> leaveList = new ArrayList<>();

		try (Connection con = DBConnect.getConnection();
				PreparedStatement ps = con.prepareStatement("SELECT empid, empname FROM Employees");
				ResultSet resultSet = ps.executeQuery()) {

			while (resultSet.next()) {
				Integer empid = resultSet.getInt(EMPID );
				String empname = resultSet.getString(EMPNAME );
				LeaveModelValue leave = new LeaveModelValue();
				leave.setEmpid(empid);
				leave.setEmpname(empname);
				leaveList.add(leave);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return leaveList;
	}

	/*Admin can search leave of employees */
	public List<LeaveModelValue> leaveSearches(int empid2) {
		List<LeaveModelValue> leaveList = new ArrayList<>();

		try (Connection con = DBConnect.getConnection()) {
			StringBuilder sql = new StringBuilder("SELECT Leave.LeaveId, Leave.empid, Employees.empname, Leave.fromdate, Leave.todate, Leave.leavetype, Leave.reason, Leave.status " +
					"FROM Leave " +
					"LEFT JOIN Employees ON Leave.empid = Employees.empid " +
					"WHERE 1=1");

			int parameterIndex = 1;

			if (empid2 != 0) {
				sql.append(" AND Leave.empid = ?");
			}

			try (PreparedStatement ps = con.prepareStatement(sql.toString())) {
				if (empid2 != 0) {
					ps.setInt(parameterIndex++, empid2);
				}

				try (ResultSet resultSet = ps.executeQuery()) {
					while (resultSet.next()) {
						Integer leaveId = resultSet.getInt(LEAVE_ID );
						Integer empid = resultSet.getInt(EMPID );
						String empname = resultSet.getString(EMPNAME );
						String fromdate = resultSet.getString(FROMDATE  );
						String todate = resultSet.getString(TODATE );
						String leavetype = resultSet.getString(LEAVETYPE  );
						String reason = resultSet.getString(REASON );
						String status = resultSet.getString(STATUS );

						LeaveModelValue leave = new LeaveModelValue();
						leave.setLeaveId(leaveId);
						leave.setEmpid(empid);
						leave.setEmpname(empname);
						leave.setFromdate(fromdate);
						leave.setTodate(todate);
						leave.setLeavetype(leavetype);
						leave.setReason(reason);
						leave.setStatus(status);

						leaveList.add(leave);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return leaveList;
	}
}

