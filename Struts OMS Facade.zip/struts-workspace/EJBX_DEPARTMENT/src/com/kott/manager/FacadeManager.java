package com.kott.manager;

import java.util.List;

import com.kott.ejbx.DepartmentModelValue;

public interface FacadeManager {
	
public String addDept(DepartmentModelValue model);
public List<DepartmentModelValue> viewDept();
public String deleteDept(DepartmentModelValue model);
public List<DepartmentModelValue> editPageList(DepartmentModelValue model);
public String editDept(DepartmentModelValue model);
public DepartmentModelValue deoptObj(String deptID);

}
