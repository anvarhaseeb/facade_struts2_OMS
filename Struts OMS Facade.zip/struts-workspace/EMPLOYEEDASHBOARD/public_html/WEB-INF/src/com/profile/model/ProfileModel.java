package com.profile.model;

import java.util.List;

public class ProfileModel {
	private int empid;
	private String empname;
	private String dob;
	private String qualification;
	private String phn;
	private String email;
	private int exp;
	private String cmpname;
	private String address;
	private String doj;
	private String dept;
	List<ProfileModel>EmpList ;
	private String username;
	private String type;


	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<ProfileModel> getEmpList() {
		return EmpList;
	}
	public void setEmpList(List<ProfileModel> empList) {
		EmpList = empList;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		if (dob != null && !dob.isEmpty() && !dob.equals("1900-01-01")) {
			this.dob = dob;
		} else {
			this.dob = null;
		}
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getPhn() {
		return phn;
	}
	public void setPhn(String phn) {
		this.phn = phn;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp) {
		this.exp = exp;
	}
	public String getCmpname() {
		return cmpname;
	}
	public void setCmpname(String cmpname) {
		this.cmpname = cmpname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		if (doj != null && !doj.isEmpty() && !doj.equals("1900-01-01")) {
			this.doj = doj;
		} else {
			this.doj = null;
		}
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}


	@Override
	public String toString() {
		return "EmployeeModel [empid=" + empid + ", empname=" + empname + ", dob=" + dob + ", qualification="
				+ qualification + ", phn=" + phn + ", email=" + email + ", exp=" + exp + ", cmpname=" + cmpname
				+ ", address=" + address + ", doj=" + doj + ", dept=" + dept + "]";
	}
}
