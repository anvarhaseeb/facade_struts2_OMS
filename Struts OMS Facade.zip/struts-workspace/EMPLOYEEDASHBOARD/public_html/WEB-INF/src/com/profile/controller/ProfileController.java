/*The controller class that retuen list of datas of employee profile*/
package com.profile.controller;

import java.util.List;

import com.kott.ejbx.ProfileModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;


public class ProfileController {

	public List<ProfileModelValue> empListCtrl(int empid) {
		FacadeManager facade =new  FacadeManagerBean();
		return facade.empListShow(empid);

	}


}
