package com.kott.manager;

import java.util.List;

import com.kott.ejbx.AnnounceModelValue;

public interface FacadeManager {
	
	public String sendAnnounce(AnnounceModelValue model) ;
	public List<AnnounceModelValue> viewAnnounce(AnnounceModelValue model) ;
	public String deleteAnnounce(int aid) ;

}
