package com.announcement.conroller;

import java.util.Collections;
import java.util.List;


import com.kott.ejbx.AnnounceModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;


public class AnnounceController {

	FacadeManager facade = new FacadeManagerBean() ;

	/*Admin-to Send announcements */
	public String sendAnnounceCtrl(AnnounceModelValue modelValue) {
		return facade.sendAnnounce(modelValue);
	}

	/*Admin and employee-to view announcements  */
	public List<AnnounceModelValue> viewAnnounceCtrl(AnnounceModelValue modelValue) { 
		List<AnnounceModelValue> announceList =facade.viewAnnounce(modelValue);
		Collections.reverse(announceList);
		return announceList; 
	}
	
	/*Admin-to delete announcement  */
	public String deleteAnnounceCtrl(int aid) {
		return facade.deleteAnnounce(aid);

	}

}
