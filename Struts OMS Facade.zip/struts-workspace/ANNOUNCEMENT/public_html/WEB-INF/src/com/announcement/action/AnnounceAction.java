/*Announce.java => the module is used by admin and employees, where admin can share announcement and employee and admin can see announcement .*/
package com.announcement.action;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import org.apache.struts2.interceptor.SessionAware;
import com.announcement.conroller.AnnounceController;
import com.announcement.model.AnnounceModel;
import com.kott.ejbx.AnnounceModelValue;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import com.profile.model.ProfileModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AnnounceAction extends ActionSupport implements ModelDriven<AnnounceModel > ,Preparable,SessionAware{

	private static final long serialVersionUID = 1L;
	private transient  AnnounceModel model ;
	private transient AnnounceController announceController ;
	private transient AnnounceModelValue modelValue ;
	private transient Map<String, Object> session;
	private static final Logger logger = LoggerFactory.getLogger(AnnounceAction.class);
	private static final String USERNAME = "username";

	/*Admin-to Send announcement page */
	public String announce() {
		logger.info("in announce");
		if (model.getUsername() != null) {
			session.put(USERNAME, model.getUsername());
		}
		return SUCCESS;
	}

	/*Admin-Send announcement*/
	public String send() {
		if (model.getUsername() != null) {

			session.put(USERNAME, model.getUsername());
			session.put("type", model.getType());
		}

		modelValue.setUsername(model.getUsername());
		modelValue.setAnnounced_date(model.getAnnounced_date());
		modelValue.setMessage(model.getMessage());
		modelValue.setType(model.getType());

		String types= announceController.sendAnnounceCtrl(modelValue);
		model.setType(modelValue.getType());
		model.setType(model.getType());

		return types;
	}
	/*Admin & employee -read  announcement*/
	public String view() {
		modelValue.setUsername(model.getUsername());
		modelValue.setAnnounced_date(model.getAnnounced_date());
		modelValue.setMessage(model.getMessage());
		modelValue.setType(model.getType());
		List<AnnounceModelValue> announceValueList = announceController.viewAnnounceCtrl(modelValue);
		List<AnnounceModel> announceList = new ArrayList<>();

		announceValueList.forEach(x -> {
			AnnounceModel announceModel = new AnnounceModel();
			announceModel.setAid(x.getAid());
			announceModel.setUsername(x.getUsername()); 
			announceModel.setAnnounced_date(x.getAnnounced_date());
			announceModel.setMessage(x.getMessage()); 
			announceModel.setType(x.getType()); 
			announceList.add(announceModel);
		});
		model.setAnnounceList(announceList);
		model.setUsername(modelValue.getUsername());
		if (model.getUsername() != null) 
		{
			session.put(USERNAME, model.getUsername());

		}
		return SUCCESS; 
	}
	/*Admin-delete announcement*/
	public String delete() {
		modelValue.setAid(model.getAid());
		String types = announceController.deleteAnnounceCtrl(modelValue.getAid());
		model.setType(modelValue.getType());
		model.setType(model.getType());
		return types; 
	}
	@Override
	public AnnounceModel getModel() {

		return model;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		this.session =session;
	}

	@Override
	public void prepare() throws Exception {
		model = new AnnounceModel();
		announceController = new AnnounceController();
		modelValue = new AnnounceModelValue();
	}

}
