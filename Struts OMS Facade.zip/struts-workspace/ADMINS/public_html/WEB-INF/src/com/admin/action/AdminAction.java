/*The AdminAction.java=> whether the admin can use crud operations on employee data*/
package com.admin.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.json.JSONArray;

import com.admin.controller.AdminController;
import com.admin.model.DepartmentModel;
import com.admin.model.EmployeeModel;
import com.kott.ejbx.DepartmentModelValue;
import com.kott.ejbx.EmployeeModelValue;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;

public class AdminAction extends ActionSupport implements ModelDriven<EmployeeModel > , Preparable ,SessionAware {

	private static final long serialVersionUID = 1L;
	private transient EmployeeModel   model ;
	private transient EmployeeModelValue modelValue = new EmployeeModelValue();
	private transient List<DepartmentModelValue>  deptValueList = new ArrayList<>(); ;
	private transient  List<DepartmentModel>  deptList = new ArrayList<>();
	private transient  AdminController adminController = new AdminController();
	private transient JSONArray  empListJson;
	private transient Map<String, Object> session;

	/*home page=>mainly to show  the search employee page*/
	public String home() {

		deptValueList = adminController.viewDeptCtrlforSearch(); 

		deptValueList.forEach(x ->{
			DepartmentModel dept =new DepartmentModel();
			dept.setDeptID(x.getDeptID());
			dept.setDeptname(x.getDeptname());
			deptList.add(dept);
		});

		model.setDeptList(deptList);
		if (model.getUsername() != null) {

			session.put("username", model.getUsername());
			session.put("type", model.getType());
		}
		return SUCCESS;
	}

	/*To redirect to add method*/
	public String addPage() { 
		model.setActionName("ADD");
		deptValueList = adminController.viewDeptCtrlforSearch(); 
		deptValueList.forEach(x ->{
			DepartmentModel dept =new DepartmentModel();
			dept.setDeptID(x.getDeptID());
			dept.setDeptname(x.getDeptname());
			deptList.add(dept);
		});
		model.setDeptList(deptList);
		return SUCCESS;
	}

	/*To redirect to edit method*/
	public String editPage() {
		model.setActionName("EDIT");
		modelValue.setEmpid(model.getEmpid());
		modelValue =adminController.emplistCtrl(modelValue.getEmpid());

		model.setEmpid(modelValue.getEmpid());
		model.setEmpname(modelValue.getEmpname());
		model.setDob(modelValue.getDob());
		model.setQualification(modelValue.getQualification());
		model.setPhn(modelValue.getPhn());
		model.setEmail(modelValue.getEmail());
		model.setExp(modelValue.getExp());
		model.setCmpname(modelValue.getCmpname());
		model.setAddress(modelValue.getAddress());
		model.setDoj(modelValue.getDoj());
		model.setDept(modelValue.getDept());


		deptValueList = adminController.viewDeptCtrlforSearch(); 
		deptValueList.forEach(x ->{
			DepartmentModel dept =new DepartmentModel();
			dept.setDeptID(x.getDeptID());
			dept.setDeptname(x.getDeptname());
			deptList.add(dept);
		});

		model.setDeptList(deptList);

		return SUCCESS;
	}

	public String actionEmp() {
		deptValueList = adminController.viewDeptCtrlforSearch(); 
		deptValueList.forEach(x ->{
			DepartmentModel dept =new DepartmentModel();
			dept.setDeptID(x.getDeptID());
			dept.setDeptname(x.getDeptname());
			deptList.add(dept);
		});
		model.setDeptList(deptList);

		if(model.getActionName().equals("ADD")) {

			modelValue.setEmpid(model.getEmpid());
			modelValue.setEmpname(model.getEmpname());
			modelValue.setDob(model.getDob());
			modelValue.setQualification(model.getQualification());
			modelValue.setPhn(model.getPhn());
			modelValue.setEmail(model.getEmail());
			modelValue.setExp(model.getExp());
			modelValue.setCmpname(model.getCmpname());
			modelValue.setAddress(model.getAddress());
			modelValue.setDoj(model.getDoj());
			modelValue.setDept(model.getDept());

			String type = adminController.addEmpCtrl(modelValue);
			addActionMessage("The data inserted successfully"); 
			return type;
		}
		else if(model.getActionName().equals("EDIT")) {
			modelValue.setEmpid(model.getEmpid());
			modelValue.setEmpname(model.getEmpname());
			modelValue.setDob(model.getDob());
			modelValue.setQualification(model.getQualification());
			modelValue.setPhn(model.getPhn());
			modelValue.setEmail(model.getEmail());
			modelValue.setExp(model.getExp());
			modelValue.setCmpname(model.getCmpname());
			modelValue.setAddress(model.getAddress());
			modelValue.setDoj(model.getDoj());
			modelValue.setDept(model.getDept());

			String type = adminController.editEmpCtrl(modelValue);
			addActionMessage("The data edited successfully"); 
			return type;
		}
		else {
			return ERROR;
		}

	}

	/* Search */
	public String search() {

		modelValue.setEmpid(model.getEmpid());
		modelValue.setEmpname(model.getEmpname());
		modelValue.setDob(model.getDob());
		modelValue.setQualification(model.getQualification());
		modelValue.setPhn(model.getPhn());
		modelValue.setEmail(model.getEmail());
		modelValue.setExp(model.getExp());
		modelValue.setCmpname(model.getCmpname());
		modelValue.setAddress(model.getAddress());
		modelValue.setDoj(model.getDoj());
		modelValue.setDept(model.getDept());

		empListJson = adminController.searchCtrl(modelValue); 
		model.setEmpListJson(empListJson);
		model.setUsername((String)session.get("username"));
		return "success";
	}

	/* delete */
	public String delete()  {

		modelValue =adminController.emplistCtrl(model.getEmpid());

		model.setEmpid(modelValue.getEmpid());
		model.setEmpname(modelValue.getEmpname());
		model.setDob(modelValue.getDob());
		model.setQualification(modelValue.getQualification());
		model.setPhn(modelValue.getPhn());
		model.setEmail(modelValue.getEmail());
		model.setExp(modelValue.getExp());
		model.setCmpname(modelValue.getCmpname());
		model.setAddress(modelValue.getAddress());
		model.setDoj(modelValue.getDoj());
		model.setDept(modelValue.getDept());

		String type = adminController.deleteCtrl(modelValue); 
		if(type.equals("cannotDelete")) {

			addActionMessage("Can't delete Admin data"); 
		}
		model.setId(modelValue.getEmpname());
		return type;
	}



	@Override
	public EmployeeModel getModel() {
		return model;
	}

	@Override
	public String execute() {
		return null;
	}


	@Override
	public void setSession(Map<String, Object> session) {
		this.session= session;

	}

	@Override
	public void prepare() throws Exception {
		  model = new EmployeeModel ();
		
	}




}
