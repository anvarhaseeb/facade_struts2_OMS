package com.admin.model;

/*DepartmenrModel.java => The model class of the department*/


public class DepartmentModel {
	private String deptID;
	private String deptname;
	public String getDeptID() {
		return deptID;
	}
	public void setDeptID(String deptID) {
		this.deptID = deptID;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	@Override
	public String toString() {
		return "DepartmentModel [deptID=" + deptID + ", deptname=" + deptname + "]";
	}
	
}
