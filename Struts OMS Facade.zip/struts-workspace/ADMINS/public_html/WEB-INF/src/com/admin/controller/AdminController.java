/*Controller class of employee creation module*/
package com.admin.controller;

import java.util.List;

import org.json.JSONArray;

import com.kott.ejbx.DepartmentModelValue;
import com.kott.ejbx.EmployeeModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;

public class AdminController {
	FacadeManager facade = new FacadeManagerBean()	 ;

	/*To  show department in select tag of employee search*/
	public  List<DepartmentModelValue> viewDeptCtrlforSearch() {
		return facade.viewDept();
	}
	
	/*To  add employee*/
	public  String addEmpCtrl(EmployeeModelValue modelValue) {
		return facade.addEmp(modelValue);
	}
	
	/*To  edit  employee*/
	public  String editEmpCtrl(EmployeeModelValue modelValue) {
		return facade.editEmp(modelValue);
	}

	/*To  search  employee*/
	public  JSONArray searchCtrl(EmployeeModelValue modelValue) {
		List<EmployeeModelValue>empList= facade.searchEmp(modelValue);
		return new JSONArray(empList);
	}
	
	/*To  delete  employee*/
	public  String deleteCtrl(EmployeeModelValue modelValue) {
		return facade.deleteEmp(modelValue);
	}
	
	/*To  show values in textfield when edit method take place*/
	public  EmployeeModelValue  emplistCtrl(int empid) {
		return facade.showEmp(empid) ;
	}


}
