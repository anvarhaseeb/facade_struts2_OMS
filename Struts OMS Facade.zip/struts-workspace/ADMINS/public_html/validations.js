$(document).ready(function() {
$('#employeeForm').on('submit',function(){
  var ValidationResult = $("#validationResult");
  var empname = $("#empname").val().trim();;
  
  
  if (empname == "") {
      ValidationResult.text("Enter the employee name");
      return false;
  }

  var firstLetter = empname.charAt(0);
  if (firstLetter !== firstLetter.toUpperCase()) {
      ValidationResult.text("First letter of the name should be a capital letter");
      return false;
  }

  var dob= $("#dob").val();
  if (dob == "") {
      ValidationResult.text("Enter the DOB");
      return false;
  }
  
  var qualification = $("#qualification").val();
  if (qualification == "") {
      ValidationResult.text("Enter the qualification");
      return false;
  }
  
var phone = $("#phn").val();
if (phone == "") {
    ValidationResult.text("Enter the phone number");
    return false;
}

var phoneRegex = /^\d{10}$/;
if (!phoneRegex.test(phone)) {
    ValidationResult.text("Phone number must be 10 digits and contain only numbers");
    return false;
}
  
  var email = $("#gmail").val();
  var mailRex = /^[A-Za-z0-9]+@[A-Za-z0-9]+\.[A-Za-z]+$/;
  if (!mailRex.test(email)) {
      ValidationResult.text("Enter a valid email address");
      return false;
  }
  
 var exp = $("#exp").val();
  if (exp == "") {
      ValidationResult.text("Enter the Experience");	
      return false;
  }
   if (isNaN(exp)) {
            ValidationResult.text("Experience must be a number");
            return false;
        }
 var cmpname = $("#cmpname").val();
  if (cmpname == "") {
      ValidationResult.text("Enter Previous Company Name ");
      return false;
  }

  var address = $("#address").val();
  if (address == "") {
      ValidationResult.text("Enter the address");
      return false;
  }

  var doj = $("#doj").val();
  if (doj == "") {
      ValidationResult.text("Enter thr date of joining");
      return false;
  }

var dept = $("#dept").val();
if (dept === "") {
    ValidationResult.text("Choose a department");
    return false;
}

}

);
$('#searchEmps').on('submit',function(){
	var ValidationResult = $("#validationResult");
	var exp = $("#exp").val();
if (isNaN(exp)) {
     ValidationResult.text("Year of Experience must be a number");
     return false;
        }
	});
});