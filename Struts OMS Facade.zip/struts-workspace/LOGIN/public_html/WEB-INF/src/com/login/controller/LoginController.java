/*LoginController.java => It is the Controller class for the login to check the type*/
package com.login.controller;

import java.util.List;

import com.kott.ejbx.EmployeeModelValue;
import com.kott.ejbx.LoginModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;

public class LoginController {
	FacadeManager facade = new FacadeManagerBean();
	
	public  LoginModelValue validatelogin(LoginModelValue modelValue) {
		
		LoginModelValue log= facade.loginCheck(modelValue);
		if ("A".equals(log.getType()) || "E".equals(log.getType())) {
			return log;
		} else {
			log.setType("invalid");
			return log;
		}

	}

	public  List<EmployeeModelValue> profileList(int empid) {
		List<EmployeeModelValue> profileList = facade.profileList(empid);
		return profileList;
	}
}


