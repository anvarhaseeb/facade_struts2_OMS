package com.department.action;

import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.json.JSONArray;

import com.department.controller.DepartmentController;
import com.department.model.DepartmentModel;
import com.kott.ejbx.DepartmentModelValue;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;

public class DepartmentAction extends ActionSupport implements ModelDriven<DepartmentModel>, Preparable ,SessionAware {

	private static final long serialVersionUID = 1L;
	private transient DepartmentModel model ;
	private transient DepartmentModelValue departmentModelValue ;
	private transient DepartmentController departmentController ;
	private transient Map<String, Object> session;

	/*to add page*/
	public String addPage() {
		session.put("type", model.getType());
		session.put("username", model.getUsername());
		model.setActionName("ADD");
		return SUCCESS;
	}

	/* view Department */
	public String view() {
		JSONArray deptListJson = departmentController.viewDeptCtrl();
		model.setDeptListJson(deptListJson);
		return SUCCESS;
	}

	/*Delete method*/
	public String delete() {
		departmentModelValue.setDeptID(model.getDeptID());
		departmentModelValue.setDeptname(model.getDeptname());
		return departmentController.deleteDeptCtrl(departmentModelValue);

	}

	/*to EditPage*/
	public String editPage() {
		model.setActionName("EDIT");
		departmentModelValue.setDeptID(model.getDeptID());
		departmentModelValue.setDeptname(model.getDeptname());

		departmentModelValue = departmentController.deptobjCtrl(departmentModelValue.getDeptID());
		model.setDeptID(departmentModelValue.getDeptID());
		model.setDeptname(departmentModelValue.getDeptname());
		return SUCCESS;
	}

	/*actionEmp-ADD or Delete */
	public String actionEmp() {
		departmentModelValue.setDeptID(model.getDeptID());
		departmentModelValue.setDeptname(model.getDeptname());

		if (model.getActionName().equals("ADD")) {
			String type = departmentController.addDeptCtrl(departmentModelValue);
			addActionMessage("The data inserted successfully");
			return type;
		} else if (model.getActionName().equals("EDIT")) {
			return   departmentController.editDeptCtrl(departmentModelValue);

		} else {
			return "error";
		}
	}

	@Override
	public DepartmentModel getModel() {
		return model;
	}

	@Override
	public String execute() throws Exception {
		return null;
	}

	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	@Override
	public void prepare() throws Exception {
		model = new DepartmentModel();
		departmentModelValue = new DepartmentModelValue();
		departmentController = new DepartmentController();

	}
}
