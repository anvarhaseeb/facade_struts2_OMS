/*DepartmentController.java => The java file mainly the bridge between action class and Dao class*/

package com.department.controller;

import java.util.List;

import org.json.JSONArray;

import com.kott.ejbx.DepartmentModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;

public class DepartmentController {

	FacadeManager facadeManager = new FacadeManagerBean();

	public String addDeptCtrl(DepartmentModelValue modelValue) {
		return facadeManager.addDept(modelValue);
	}

	public JSONArray viewDeptCtrl() {
		List<DepartmentModelValue> deptList = facadeManager.viewDept();
		return new JSONArray(deptList);
	}

	public  String deleteDeptCtrl(DepartmentModelValue modelValue) {
		return facadeManager.deleteDept(modelValue);
	}

	public  List<DepartmentModelValue> editPageCtrl(DepartmentModelValue modelValue) {		
		return facadeManager.editPageList(modelValue);
	}

	public  String editDeptCtrl(DepartmentModelValue model) {
		return facadeManager.editDept(model);
	}

	public DepartmentModelValue deptobjCtrl(String deptID) {
		return facadeManager.deoptObj(deptID) ;
	}

}
