package com.leave.model;

import java.util.List;

import org.json.JSONArray;

public class LeaveModel {
private int leaveId;
private int empid;
private String fromdate;
private String todate;
private String leavetype;
private String reason;
private String status;
private JSONArray leaveLists ;
private String type;
private String username;
private String empname;
private String usernames;
private String actionMessage;
private List <LeaveModel> employeeList;
public int getLeaveId() {
	return leaveId;
}
public void setLeaveId(int leaveId) {
	this.leaveId = leaveId;
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}

public String getFromdate() {
	return fromdate;
}
public void setFromdate(String fromdate) {
	this.fromdate = fromdate;
}
public String getTodate() {
	return todate;
}
public void setTodate(String todate) {
	this.todate = todate;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getReason() {
	return reason;
}
public void setReason(String reason) {
	this.reason = reason;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getLeavetype() {
	return leavetype;
}
public void setLeavetype(String leavetype) {
	this.leavetype = leavetype;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}

public JSONArray getLeaveLists() {
	return leaveLists;
}

public void setLeaveLists(JSONArray leaveLists) {
	this.leaveLists = leaveLists;
}

public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}

public String getActionMessage() {
	return actionMessage;
}
public void setActionMessage(String actionMessage) {
	this.actionMessage = actionMessage;
}

public String getUsernames() {
	return usernames;
}
public void setUsernames(String usernames) {
	this.usernames = usernames;
}

public List<LeaveModel> getEmployeeList() {
	return employeeList;
}
public void setEmployeeList(List<LeaveModel> employeeList) {
	this.employeeList = employeeList;
}
@Override
public String toString() {
	return "LeaveModel [LeaveId=" + leaveId + ", empid=" + empid + ", fromdate=" + fromdate + ", todate=" + todate
			+ ", leavetype=" + leavetype + ", reason=" + reason + ", status=" + status + ", type=" + type
			+ ", username=" + username +  "]";
}



}
