/*LeaveController.java-> The Controller class for Leave Module and it goes to the interface to FacadeManager*/

package com.leave.controller;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.json.JSONArray;

import com.kott.ejbx.LeaveModelValue;
import com.kott.manager.FacadeManager;
import com.kott.manager.FacadeManagerBean;

public class LeaveController {
	FacadeManager facade = new FacadeManagerBean();
	private static final String APPROVED = "approved";
	private static final String PENDING = "pending";
	private static final String REJECTED = "rejected";

	public String leaveApply(LeaveModelValue modelValue) {
		return facade.applyleave(modelValue);

	}

	public JSONArray leaveStatus(int empid) {
		List<LeaveModelValue> leaveList = facade.leaveStatus(empid);

		List<LeaveModelValue> sortedList = leaveList.stream()
				.sorted(Comparator.comparing((LeaveModelValue leave) -> {
					switch (leave.getStatus()) {
					case PENDING:
						return 0;
					case APPROVED:
						return 1;
					case REJECTED:
						return 2;
					default:
						return 3;
					}
				}))
				.collect(Collectors.toList());

		JSONArray leavesList = new JSONArray(sortedList);
		return leavesList;
	}



	public JSONArray leavePageAdmin() {
		List<LeaveModelValue> leaveList = facade.leaveStatusAdmin();
		List<LeaveModelValue> sortedList = leaveList.stream()
				.sorted(Comparator.comparing((LeaveModelValue leave) -> {
					switch (leave.getStatus()) {
					case PENDING:
						return 0;
					case APPROVED:
						return 1;
					case  REJECTED:
						return 2;
					default:
						return 3;
					}
				}))
				.collect(Collectors.toList());

		JSONArray leavesList = new JSONArray(sortedList);
		return leavesList;
	}

	public String leaveApprove(int leaveId) {
		return facade.approveLeave(leaveId);

	}

	public String leaveDeny(int leaveId) {
		return facade.denyLeave(leaveId);

	}

	public String leaveDelete(int leaveId) {
		return facade.deleteLeave(leaveId);
	}

	public List<LeaveModelValue> empList() {
		return  facade.empLists();

	}

	public JSONArray leaveSearch(int empid) {
		List<LeaveModelValue> leaveList = facade.leaveSearches(empid);

		List<LeaveModelValue> sortedList = leaveList.stream()
				.sorted(Comparator.comparing((LeaveModelValue leave) -> {
					switch (leave.getStatus()) {
					case PENDING:
						return 0;
					case  APPROVED:
						return 1;
					case  REJECTED:
						return 2;
					default:
						return 3;
					}
				}))
				.collect(Collectors.toList());

		return new JSONArray(sortedList);

	}




}
