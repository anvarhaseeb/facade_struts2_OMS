/*LeaveAction.java-> The action class for Leave Module*/
package com.leave.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.json.JSONArray;

import com.kott.ejbx.LeaveModelValue;
import com.leave.controller.LeaveController;
import com.leave.model.LeaveModel;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import com.opensymphony.xwork2.interceptor.ValidationAware;

public class LeaveAction extends ActionSupport implements ModelDriven<LeaveModel> , Preparable,SessionAware,ValidationAware{

	private static final long serialVersionUID = 1L;
	private static final String SESSION_EMPID = "empid";
	private static final String SESSION_USERNAME = "username";
	private static final String SUCCESS = "success";

	private transient LeaveModel model ;
	private transient LeaveModelValue modelValue ;
	private transient Map<String, Object> session;
	private transient LeaveController leaveController ;

	public String leaveSearchPage() {

		session.put(SESSION_EMPID, model.getEmpid());
		session.put(SESSION_USERNAME, model.getUsername());
		List<LeaveModelValue> employeeValueList = leaveController.empList(); 
		List<LeaveModel> employeeList = new ArrayList();
		employeeValueList.forEach(x ->{
			LeaveModel emp =new LeaveModel();
			emp.setEmpid(x.getEmpid());
			emp.setEmpname(x.getEmpname());
			employeeList.add(emp);
		});
		model.setEmployeeList(employeeList);
		return SUCCESS;
	}

	public String leaveSearch() {

		modelValue.setEmpid(model.getEmpid());
		JSONArray  leaveLists = leaveController.leaveSearch(modelValue.getEmpid());
		model.setLeaveLists(leaveLists);
		model.setEmpid((Integer) session.get(SESSION_EMPID));
		model.setUsername((String) session.get(SESSION_USERNAME));

		return SUCCESS;
	}

	public String leave() {

		session.put(SESSION_EMPID, model.getEmpid());
		session.put(SESSION_USERNAME, model.getUsername());
		int empid = (Integer) session.get("empid");
		model.setEmpid(empid);
		model.setUsername(model.getUsername());
		return SUCCESS;
	}

	/*LeaveApply  -by employee*/
	public String leaveApply() {

		if(!validLogin()) {	
			return "input";
		}
		modelValue.setEmpid(model.getEmpid());
		modelValue.setFromdate(model.getFromdate());
		modelValue.setTodate(model.getFromdate());
		modelValue.setLeavetype(model.getLeavetype());
		modelValue.setReason(model.getReason());
		modelValue.setStatus(model.getStatus());
		modelValue.setUsername(model.getUsername());

		String str = leaveController.leaveApply(modelValue);		
		model.setEmpid(modelValue.getEmpid());
		model.setUsername(modelValue.getUsername());

		return str;
	}

	/*LeaveStatus  -by employee*/
	public String leaveStatus() {
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getUsername());
		JSONArray  leaveLists = leaveController.leaveStatus(modelValue.getEmpid());
		model.setLeaveLists(leaveLists);
		model.setEmpid(modelValue.getEmpid());
		model.setUsername(modelValue.getUsername());

		session.put("empid", model.getEmpid());
		session.put("username", model.getUsername());
		return SUCCESS;
	}


	/*Leave  Reject or Approve  -by admin*/
	public String leaveAdmin() {

		if (model.getUsername() != null) {
			session.put("empid", model.getEmpid());
			session.put("username", model.getUsername());
		}
		JSONArray  leaveLists = leaveController.leavePageAdmin();
		model.setLeaveLists(leaveLists);
		return SUCCESS";
	}
	/*LeaveDatas   -by admin*/
	public String leaveDatas() {

		if (model.getUsernames() != null) {
			session.put("username", model.getUsernames());
			session.put("empid", model.getEmpid());
		} 

		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getUsername());
		JSONArray  leaveLists = leaveController.leaveSearch(modelValue.getEmpid());

		/* JSONArray leaveLists = leaveController.leaveStatus(modelValue.getEmpid()); */
		model.setLeaveLists(leaveLists);
		model.setEmpid( (Integer) session.get("empid"));
		model.setUsername( (String) session.get("username"));
		return "success";
	}
	/*Leave  Approve  -by admin*/
	public String toApprove() {
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getUsername());
		modelValue.setLeaveId(model.getLeaveId());
		String  str = leaveController.leaveApprove(modelValue.getLeaveId());
		model.setActionMessage("Approved"); 
		model.setEmpid(modelValue.getEmpid());
		model.setUsername(modelValue.getUsername());
		return str;
	}
	/*Leave  Approve  -by admin*/
	public String toDeny() {


		modelValue.setLeaveId(model.getLeaveId());
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getEmpname());

		String  str = leaveController.leaveDeny(modelValue.getLeaveId());
		model.setActionMessage("Rejected"); 
		model.setEmpid(modelValue.getEmpid());

		model.setUsername(modelValue.getUsername());

		return str;
	}
	/*Leave  Approve  -by employee*/
	public String toDelete() {
		modelValue.setLeaveId(model.getLeaveId());
		modelValue.setEmpid(model.getEmpid());
		modelValue.setUsername(model.getEmpname());
		String  str = leaveController.leaveDelete(modelValue.getLeaveId());

		model.setEmpid((Integer) session.get("empid"));
		model.setUsername((String) session.get("username"));

		model.setActionMessage("Deleted"); 
		return str;
	}

	/*Validation Checking of the Employee Dashboard's leave Applying*/
	public boolean validLogin() {

		if (model.getFromdate().equals(model.getTodate())) {
			addFieldError("model.todate", "The from and To dates can't be Same");
			return false;
		}
		if (model.getLeavetype() == null || model.getLeavetype().isEmpty()) {
			addFieldError("model.leavetype", "Please select a leave type");
			return false;
		}

		String reason = model.getReason();
		if (reason == null || reason.isEmpty()) {
			addFieldError("model.reason", "Reason can't be blank");
			return false;
		}

		else {
			return true;
		}
	}

	@Override
	public void setSession(Map<String, Object> session) {

		this.session = session;
	}

	@Override
	public LeaveModel getModel() {

		return model;
	}
	@Override
	public String execute() throws Exception {
		return null;
	}

	@Override
	public void prepare() throws Exception {
		model = new LeaveModel();
		modelValue = new LeaveModelValue();
		leaveController = new LeaveController();
	}

}

