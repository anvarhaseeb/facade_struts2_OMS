package com.kott.manager;

import java.util.List;

import com.kott.ejbx.ProfileModelValue;

public interface FacadeManager {

	public List<ProfileModelValue> empListShow(int empid) ;

}
