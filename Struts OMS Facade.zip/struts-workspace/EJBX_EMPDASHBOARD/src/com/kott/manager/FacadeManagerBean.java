package com.kott.manager;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.kott.database.DBConnect;
import com.kott.ejbx.ProfileModelValue;

public class FacadeManagerBean implements FacadeManager {
	static Connection  con = DBConnect.getConnection();
	List<ProfileModelValue>empList = new ArrayList<>();

	public List<ProfileModelValue> empListShow(int empid) {
		String sql = "SELECT * FROM Employees WHERE empid = ?";

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setInt(1, empid);  
			ResultSet resultSet = ps.executeQuery();

			if (resultSet.next()) {
				ProfileModelValue employee = new ProfileModelValue();
				employee.setEmpid(resultSet.getInt("empid"));
				employee.setEmpname(resultSet.getString("empname"));
				employee.setDob(resultSet.getString("dob"));
				employee.setQualification(resultSet.getString("qualification"));
				employee.setPhn(resultSet.getString("phn"));
				employee.setEmail(resultSet.getString("email"));
				employee.setExp(resultSet.getInt("exp"));
				employee.setCmpname(resultSet.getString("cmpname"));
				employee.setAddress(resultSet.getString("address"));
				employee.setDoj(resultSet.getString("doj"));
				employee.setDept(resultSet.getString("dept"));
				empList.add(employee);
				return empList;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return empList;
	}

}
